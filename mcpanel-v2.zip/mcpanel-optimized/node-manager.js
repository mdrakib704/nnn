/**
 * Node Manager — connects panel to Wing daemons on remote VPS
 * Panel থেকে অন্য VPS এর Wing daemon এ connect করে
 */
'use strict';

const WebSocket = require('ws');
const EventEmitter = require('events');

class NodeManager extends EventEmitter {
  constructor() {
    super();
    this.nodes = new Map(); // nodeId -> { ws, info, pending, connected }
    this.setMaxListeners(200);
  }

  connect(nodeId, wsUrl, token) {
    if (this.nodes.has(nodeId)) {
      const n = this.nodes.get(nodeId);
      if (n.ws && n.ws.readyState < 2) return; // already connected
    }

    const node = { ws: null, info: {}, pending: new Map(), connected: false, url: wsUrl, token };
    this.nodes.set(nodeId, node);

    const ws = new WebSocket(wsUrl, { handshakeTimeout: 10000 });
    node.ws = ws;

    ws.on('open', () => {
      ws.send(JSON.stringify({ type: 'auth', token }));
    });

    ws.on('message', (raw) => {
      let msg;
      try { msg = JSON.parse(raw.toString()); } catch { return; }

      if (msg.type === 'auth_ok') {
        node.connected = true;
        node.info = msg;
        this.emit('node_connected', { nodeId, info: msg });
        console.log(`[NodeManager] Node ${nodeId} connected: ${wsUrl}`);
        return;
      }
      if (msg.type === 'error' && !node.connected) {
        console.error(`[NodeManager] Node ${nodeId} auth failed`);
        ws.close();
        return;
      }

      // Resolve pending promises
      if (msg.reqId && node.pending.has(msg.reqId)) {
        const { resolve } = node.pending.get(msg.reqId);
        node.pending.delete(msg.reqId);
        resolve(msg);
        return;
      }

      // Forward events to panel
      this.emit('node_event', { nodeId, msg });
    });

    ws.on('close', () => {
      node.connected = false;
      this.emit('node_disconnected', { nodeId });
      // Reject all pending
      for (const [, { reject }] of node.pending) reject(new Error('Node disconnected.'));
      node.pending.clear();
      // Auto-reconnect after 10s
      setTimeout(() => {
        if (this.nodes.has(nodeId)) this.connect(nodeId, wsUrl, token);
      }, 10000);
    });

    ws.on('error', (e) => {
      console.error(`[NodeManager] Node ${nodeId} error:`, e.message);
    });
  }

  disconnect(nodeId) {
    const node = this.nodes.get(nodeId);
    if (!node) return;
    if (node.ws) { try { node.ws.close(); } catch {} }
    this.nodes.delete(nodeId);
  }

  send(nodeId, msg, timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      const node = this.nodes.get(nodeId);
      if (!node || !node.connected || node.ws.readyState !== 1) {
        return reject(new Error(`Node ${nodeId} not connected.`));
      }
      const reqId = Math.random().toString(36).slice(2);
      msg.reqId = reqId;
      node.pending.set(reqId, { resolve, reject });
      setTimeout(() => {
        if (node.pending.has(reqId)) {
          node.pending.delete(reqId);
          reject(new Error('Node request timed out.'));
        }
      }, timeoutMs);
      try { node.ws.send(JSON.stringify(msg)); }
      catch (e) { node.pending.delete(reqId); reject(e); }
    });
  }

  // Fire-and-forget (no response needed)
  emit2(nodeId, msg) {
    const node = this.nodes.get(nodeId);
    if (!node || !node.connected) return false;
    try { node.ws.send(JSON.stringify(msg)); return true; } catch { return false; }
  }

  isConnected(nodeId) {
    const n = this.nodes.get(nodeId);
    return !!(n && n.connected);
  }

  getStatus(nodeId) {
    const n = this.nodes.get(nodeId);
    if (!n) return 'not_configured';
    if (!n.ws || n.ws.readyState > 1) return 'disconnected';
    if (!n.connected) return 'connecting';
    return 'connected';
  }

  allNodes() {
    const result = [];
    for (const [id, n] of this.nodes) {
      result.push({ id, url: n.url, connected: n.connected, info: n.info });
    }
    return result;
  }
}

module.exports = new NodeManager();
