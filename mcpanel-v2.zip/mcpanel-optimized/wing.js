/**
 * MC Panel — Wing Daemon v1.0
 * ============================
 * Runs on REMOTE VPS nodes.
 * The main panel connects to this via WebSocket.
 *
 * Install on each node VPS:
 *   node wing.js
 *
 * Config via environment variables:
 *   WING_TOKEN=secret123   (must match panel node token)
 *   WING_PORT=8080         (default 8080)
 */

'use strict';

const { spawn }  = require('child_process');
const http       = require('http');
const path       = require('path');
const fs         = require('fs');
const os         = require('os');
const { WebSocketServer, WebSocket } = require('ws');

const TOKEN      = process.env.WING_TOKEN || 'changeme';
const PORT       = parseInt(process.env.WING_PORT)  || 8080;
const SERVERS_DIR = process.env.WING_SERVERS_DIR || path.join(__dirname, 'wing-servers');

fs.mkdirSync(SERVERS_DIR, { recursive: true });

// ── In-memory process registry ──────────────────────────────────
const procs = new Map(); // serverId -> { proc, logs, stats }

// ── HTTP server (health check) ───────────────────────────────────
const httpServer = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      ok: true,
      servers: procs.size,
      uptime: os.uptime(),
      memory: { free: os.freemem(), total: os.totalmem() }
    }));
  } else {
    res.writeHead(404); res.end('Not found');
  }
});

// ── WebSocket server ─────────────────────────────────────────────
const wss = new WebSocketServer({ server: httpServer });

function send(ws, obj) {
  try { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); } catch {}
}

function broadcastToPanel(obj) {
  for (const client of wss.clients) {
    if (client._authenticated) send(client, obj);
  }
}

// ── System stats ─────────────────────────────────────────────────
let lastCpus = os.cpus();
function getCpuPercent() {
  const cpus = os.cpus();
  let idle = 0, total = 0;
  for (let i = 0; i < cpus.length; i++) {
    const p = lastCpus[i] ? lastCpus[i].times : cpus[i].times;
    const c = cpus[i].times;
    const pt = Object.values(p).reduce((a,b)=>a+b,0);
    const ct = Object.values(c).reduce((a,b)=>a+b,0);
    idle  += c.idle  - p.idle;
    total += ct - pt;
  }
  lastCpus = cpus;
  return total > 0 ? Math.round((1 - idle/total)*1000)/10 : 0;
}

function sysStats() {
  const mem = { total: os.totalmem(), free: os.freemem() };
  return {
    cpu: getCpuPercent(),
    memUsedMb: Math.round((mem.total - mem.free)/1024/1024),
    memTotalMb: Math.round(mem.total/1024/1024),
    uptime: os.uptime(),
    load: os.loadavg(),
    servers: procs.size
  };
}

// Broadcast system stats every 5s
setInterval(() => {
  broadcastToPanel({ type: 'system_stats', data: sysStats() });
}, 5000);

// Broadcast server stats every 3s
setInterval(() => {
  for (const [id, entry] of procs) {
    broadcastToPanel({
      type: 'server_stats',
      serverId: id,
      data: {
        status:    'running',
        players:   entry.stats.players,
        maxPlayers:entry.stats.maxPlayers,
        tps:       entry.stats.tps,
        uptime:    Date.now() - entry.startedAt
      }
    });
  }
}, 3000);

// ── Process helpers ───────────────────────────────────────────────
function startServer(msg) {
  const { serverId, ramMb = 1024, port, javaPath = 'java' } = msg;
  if (procs.has(serverId)) return { ok: false, error: 'Already running.' };

  const dir = path.join(SERVERS_DIR, String(serverId));
  fs.mkdirSync(dir, { recursive: true });

  const jar = path.join(dir, 'server.jar');
  if (!fs.existsSync(jar)) {
    fs.writeFileSync(path.join(dir, 'eula.txt'), 'eula=true\n');
    return { ok: false, error: 'No server.jar found. Upload it first.' };
  }

  const args = [`-Xms256M`, `-Xmx${ramMb}M`, '-Dfile.encoding=UTF-8', '-jar', 'server.jar', 'nogui'];
  const proc = spawn(javaPath, args, { cwd: dir, env: { ...process.env, SERVER_PORT: String(port || 25565) } });

  const entry = {
    proc,
    logs:      [],
    startedAt: Date.now(),
    stats:     { players: 0, maxPlayers: 20, tps: 20 }
  };
  procs.set(serverId, entry);

  const onData = (chunk) => {
    const text = chunk.toString('utf8');
    entry.logs.push(text);
    if (entry.logs.length > 500) entry.logs.shift();
    broadcastToPanel({ type: 'console', serverId, line: text });
    // Parse player joins/leaves
    if (/joined the game/i.test(text)) entry.stats.players = Math.min(entry.stats.players+1, entry.stats.maxPlayers);
    if (/left the game/i.test(text))   entry.stats.players = Math.max(0, entry.stats.players-1);
    if (/Done \(/i.test(text))         broadcastToPanel({ type: 'server_status', serverId, status: 'running' });
  };

  proc.stdout.on('data', onData);
  proc.stderr.on('data', onData);

  proc.on('exit', (code) => {
    const msg2 = `\n[Wing] Process exited with code ${code}\n`;
    broadcastToPanel({ type: 'console',       serverId, line: msg2 });
    broadcastToPanel({ type: 'server_status', serverId, status: 'stopped' });
    procs.delete(serverId);
  });

  broadcastToPanel({ type: 'server_status', serverId, status: 'starting' });
  return { ok: true };
}

function stopServer(serverId, force = false) {
  const entry = procs.get(serverId);
  if (!entry) return { ok: false, error: 'Not running.' };
  if (force) { entry.proc.kill('SIGKILL'); }
  else {
    try { entry.proc.stdin.write('stop\n'); } catch {}
    setTimeout(() => { if (procs.has(serverId)) entry.proc.kill('SIGTERM'); }, 20000);
  }
  return { ok: true };
}

function sendCommand(serverId, command) {
  const entry = procs.get(serverId);
  if (!entry) return { ok: false, error: 'Not running.' };
  try { entry.proc.stdin.write(command + '\n'); return { ok: true }; }
  catch (e) { return { ok: false, error: e.message }; }
}

// ── File operations ───────────────────────────────────────────────
function safeResolve(serverId, relPath) {
  const base   = path.join(SERVERS_DIR, String(serverId));
  const target = path.resolve(base, relPath || '.');
  if (!target.startsWith(base)) throw new Error('Path traversal blocked.');
  return target;
}

function listFiles(serverId, relPath) {
  const target = safeResolve(serverId, relPath);
  if (!fs.existsSync(target)) fs.mkdirSync(target, { recursive: true });
  return fs.readdirSync(target, { withFileTypes: true }).map(e => {
    const st = fs.statSync(path.join(target, e.name));
    return { name: e.name, isDir: e.isDirectory(), size: st.size, modified: st.mtimeMs };
  });
}

// ── WebSocket message handler ─────────────────────────────────────
wss.on('connection', (ws) => {
  ws._authenticated = false;

  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    // Auth first
    if (!ws._authenticated) {
      if (msg.type === 'auth' && msg.token === TOKEN) {
        ws._authenticated = true;
        send(ws, { type: 'auth_ok', node: os.hostname(), stats: sysStats() });
        console.log('[Wing] Panel connected from', ws._socket && ws._socket.remoteAddress);
      } else {
        send(ws, { type: 'error', msg: 'Unauthorized.' });
        ws.close();
      }
      return;
    }

    // Commands
    const { type, serverId } = msg;
    let result;

    if      (type === 'start')   result = startServer(msg);
    else if (type === 'stop')    result = stopServer(serverId, false);
    else if (type === 'kill')    result = stopServer(serverId, true);
    else if (type === 'restart') { stopServer(serverId, false); setTimeout(() => startServer(msg), 2000); result = { ok: true }; }
    else if (type === 'command') result = sendCommand(serverId, msg.command);
    else if (type === 'logs')    result = { ok: true, logs: (procs.get(serverId)||{logs:[]}).logs.join('') };
    else if (type === 'stats')   result = { ok: true, data: sysStats() };
    else if (type === 'list_files') {
      try { result = { ok: true, files: listFiles(serverId, msg.path) }; }
      catch (e) { result = { ok: false, error: e.message }; }
    }
    else if (type === 'delete_file') {
      try {
        const target = safeResolve(serverId, msg.path);
        fs.rmSync(target, { recursive: true, force: true });
        result = { ok: true };
      } catch(e) { result = { ok: false, error: e.message }; }
    }
    else if (type === 'mkdir') {
      try {
        const target = safeResolve(serverId, msg.path);
        fs.mkdirSync(target, { recursive: true });
        result = { ok: true };
      } catch(e) { result = { ok: false, error: e.message }; }
    }
    else if (type === 'read_file') {
      try {
        const target = safeResolve(serverId, msg.path);
        if (fs.statSync(target).size > 2*1024*1024) result = { ok: false, error: 'File too large.' };
        else result = { ok: true, content: fs.readFileSync(target, 'utf8') };
      } catch(e) { result = { ok: false, error: e.message }; }
    }
    else if (type === 'write_file') {
      try {
        const target = safeResolve(serverId, msg.path);
        fs.writeFileSync(target, msg.content || '', 'utf8');
        result = { ok: true };
      } catch(e) { result = { ok: false, error: e.message }; }
    }
    else if (type === 'rename_file') {
      try {
        const src = safeResolve(serverId, msg.from);
        const dst = safeResolve(serverId, msg.to);
        fs.renameSync(src, dst);
        result = { ok: true };
      } catch(e) { result = { ok: false, error: e.message }; }
    }
    else { result = { ok: false, error: 'Unknown command.' }; }

    if (result && msg.reqId) send(ws, { type: 'response', reqId: msg.reqId, ...result });
  });

  ws.on('close',  () => console.log('[Wing] Panel disconnected.'));
  ws.on('error',  (e) => console.error('[Wing] WS error:', e.message));
});

httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`\n✅ Wing Daemon running on port ${PORT}`);
  console.log(`   Token: ${TOKEN}`);
  console.log(`   Servers dir: ${SERVERS_DIR}\n`);
});
