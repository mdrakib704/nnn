'use strict';

const express      = require('express');
const session      = require('express-session');
const SQLiteStore  = require('connect-sqlite3')(session);
const path         = require('path');
const fs           = require('fs');
const http         = require('http');
const os           = require('os');
const crypto       = require('crypto');
const bcrypt       = require('bcryptjs');
const multer       = require('multer');
const compression  = require('compression');
const sanitize     = require('sanitize-filename');
const { spawn }    = require('child_process');
const WebSocket    = require('ws');
const { WebSocketServer } = require('ws');
const flash        = require('connect-flash');
const rateLimit    = require('express-rate-limit');
const helmet       = require('helmet');
const zlib         = require('zlib');
const { pipeline } = require('stream/promises');

// ── Local modules ─────────────────────────────────────────────────
const db          = require('./db');
const nodeManager = require('./node-manager');

const app    = express();
const server = http.createServer(app);

// ── WebSocket server (replaces socket.io — much lighter) ──────────
const wss = new WebSocketServer({ server });
const wsClients = new Map(); // ws -> { userId, serverIds: Set }

function wsSend(ws, obj) {
  try { if (ws.readyState === 1) ws.send(JSON.stringify(obj)); } catch {}
}
function wsToServer(serverId, obj) {
  for (const [ws, meta] of wsClients) {
    if (meta.serverIds.has(String(serverId))) wsSend(ws, obj);
  }
}
function wsToUser(userId, obj) {
  for (const [ws, meta] of wsClients) {
    if (meta.userId === userId) wsSend(ws, obj);
  }
}

wss.on('connection', (ws, req) => {
  wsClients.set(ws, { userId: null, serverIds: new Set() });
  ws.on('message', (raw) => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    const meta = wsClients.get(ws);
    if (!meta) return;
    if (msg.type === 'auth' && msg.userId) { meta.userId = msg.userId; return; }
    if (msg.type === 'subscribe' && msg.serverId) { meta.serverIds.add(String(msg.serverId)); return; }
    if (msg.type === 'unsubscribe' && msg.serverId) { meta.serverIds.delete(String(msg.serverId)); return; }
  });
  ws.on('close',  () => wsClients.delete(ws));
  ws.on('error',  () => wsClients.delete(ws));
});

// Forward node events to frontend WebSocket clients
nodeManager.on('node_event', ({ nodeId, msg }) => {
  if (msg.type === 'console')       wsToServer(msg.serverId, { event: 'console',      serverId: msg.serverId, data: msg.line });
  if (msg.type === 'server_status') wsToServer(msg.serverId, { event: 'serverStatus', serverId: msg.serverId, status: msg.status });
  if (msg.type === 'server_stats')  wsToServer(msg.serverId, { event: 'server-stats', serverId: msg.serverId, data: msg.data });
  if (msg.type === 'system_stats')  { /* stored per-node if needed */ }
});

// ── In-process server manager (for LOCAL node) ────────────────────
const localProcs = new Map(); // serverId -> { proc, logs, startedAt, stats }

function localSend(ws_obj_ignored, serverId, obj) { wsToServer(serverId, obj); }

function startLocalServer(server) {
  const { id, ram, port, server_type, version } = server;
  if (localProcs.has(id)) return { ok: false, error: 'Already running.' };

  const SERVERS_DIR = path.join(__dirname, 'servers');
  const dir = path.join(SERVERS_DIR, String(id));
  fs.mkdirSync(dir, { recursive: true });

  const jar = path.join(dir, 'server.jar');
  if (!fs.existsSync(jar)) {
    fs.writeFileSync(path.join(dir, 'eula.txt'), 'eula=true\n');
    return { ok: false, error: 'No server.jar found. Upload via File Manager first.' };
  }

  const args = [`-Xms256M`, `-Xmx${ram}M`, '-Dfile.encoding=UTF-8', '-jar', 'server.jar', 'nogui'];
  const proc = spawn('java', args, { cwd: dir });

  const entry = { proc, logs: [], startedAt: Date.now(), stats: { players: 0, maxPlayers: 20, tps: 20, cpu: 0, ramUsed: 0 } };
  localProcs.set(id, entry);

  db.prepare("UPDATE servers SET status='starting' WHERE id=?").run(id);
  wsToServer(id, { event: 'serverStatus', serverId: id, status: 'starting' });

  const onData = (chunk) => {
    const text = chunk.toString('utf8');
    entry.logs.push(text);
    if (entry.logs.length > 600) entry.logs.shift();
    wsToServer(id, { event: 'console', serverId: id, data: text });
    if (/Done \(/i.test(text))         { db.prepare("UPDATE servers SET status='running' WHERE id=?").run(id); wsToServer(id, { event: 'serverStatus', serverId: id, status: 'running' }); }
    if (/joined the game/i.test(text)) entry.stats.players = Math.min(entry.stats.players+1, entry.stats.maxPlayers);
    if (/left the game/i.test(text))   entry.stats.players = Math.max(0, entry.stats.players-1);
  };
  proc.stdout.on('data', onData);
  proc.stderr.on('data', onData);
  proc.on('exit', (code) => {
    const msg = `\n[Panel] Process exited (code ${code})\n`;
    wsToServer(id, { event: 'console', serverId: id, data: msg });
    wsToServer(id, { event: 'serverStatus', serverId: id, status: 'stopped' });
    db.prepare("UPDATE servers SET status='stopped' WHERE id=?").run(id);
    localProcs.delete(id);
  });
  return { ok: true };
}

// CPU tracking for local servers (lightweight, no pidusage)
let lastCpuTimes = {};
setInterval(() => {
  for (const [id, entry] of localProcs) {
    try {
      // Read /proc/{pid}/stat on Linux for CPU — fallback to 0 on other OS
      const pid = entry.proc.pid;
      if (pid && process.platform === 'linux') {
        const stat = fs.readFileSync(`/proc/${pid}/stat`, 'utf8').split(' ');
        const utime = parseInt(stat[13]), stime = parseInt(stat[14]);
        const total = utime + stime;
        const last  = lastCpuTimes[pid] || total;
        entry.stats.cpu = Math.round(((total - last) / 1) * 10) / 10;
        lastCpuTimes[pid] = total;
        // RAM from /proc/{pid}/status
        const status = fs.readFileSync(`/proc/${pid}/status`, 'utf8');
        const vmRss  = status.match(/VmRSS:\s+(\d+)/);
        if (vmRss) entry.stats.ramUsed = Math.round(parseInt(vmRss[1]) / 1024);
      }
    } catch {}
    wsToServer(id, { event: 'server-stats', serverId: id, data: { ...entry.stats, uptime: Date.now() - entry.startedAt } });
  }
}, 3000);

// ── Middleware ────────────────────────────────────────────────────
app.use(compression()); // gzip responses — saves bandwidth
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1d', etag: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.db', dir: path.join(__dirname, 'database') }),
  secret: process.env.SESSION_SECRET || 'changeme_long_random_secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 3600 * 1000, httpOnly: true, sameSite: 'strict' }
}));
app.use(flash());

// Rate limit login
const loginLimit = rateLimit({ windowMs: 5 * 60000, max: 10, message: 'Too many login attempts.' });

// ── Auth helpers ──────────────────────────────────────────────────
const requireAuth = (req, res, next) => {
  if (req.session.userId) return next();
  req.flash('error', 'Please log in.');
  res.redirect('/auth/login');
};
const requireAdmin = (req, res, next) => {
  if (req.session.userId && req.session.role === 'admin') return next();
  res.status(403).render('error', { message: 'Admin access required.', user: null, settings: db.allSettings() });
};

// ── Template locals ───────────────────────────────────────────────
app.use((req, res, next) => {
  res.locals.settings  = db.allSettings();
  res.locals.user      = null;
  res.locals.success   = req.flash('success');
  res.locals.error     = req.flash('error');
  if (req.session.userId) {
    res.locals.user = db.prepare('SELECT id,username,email,role,suspended,profile_pic,server_limit FROM users WHERE id=?').get(req.session.userId);
    if (!res.locals.user) { req.session.destroy(); return res.redirect('/auth/login'); }
    if (res.locals.user.suspended) { req.session.destroy(); return res.redirect('/auth/login?suspended=1'); }
    // Unread notification count for badge
    res.locals.unreadNotifs = db.prepare('SELECT COUNT(*) AS c FROM notifications WHERE user_id=? AND read=0').get(req.session.userId).c;
  }
  next();
});

// ── File upload config ────────────────────────────────────────────
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(__dirname, 'uploads', 'temp');
      fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => cb(null, Date.now() + '-' + sanitize(file.originalname))
  }),
  limits: { fileSize: 500 * 1024 * 1024 }
});

// ── Helper: get server (checks ownership) ─────────────────────────
function getServer(id, userId, role) {
  if (role === 'admin') return db.prepare('SELECT * FROM servers WHERE id=?').get(id);
  const own = db.prepare('SELECT * FROM servers WHERE id=? AND owner_id=?').get(id, userId);
  if (own) return own;
  return db.prepare(`SELECT s.* FROM servers s JOIN subusers su ON su.server_id=s.id WHERE s.id=? AND su.user_id=?`).get(id, userId);
}

function safeServerPath(serverId, relPath) {
  const base   = path.join(__dirname, 'servers', String(serverId));
  const target = path.resolve(base, relPath || '.');
  if (!target.startsWith(base)) throw new Error('Path traversal blocked.');
  return target;
}

// ── Helper: run on correct node ───────────────────────────────────
async function serverAction(server, action, extraData = {}) {
  if (server.node_id && nodeManager.isConnected(server.node_id)) {
    return nodeManager.send(server.node_id, { type: action, serverId: server.id, ...extraData });
  }
  // Local
  if (action === 'start')   return startLocalServer(server);
  if (action === 'stop')    { const e = localProcs.get(server.id); if (e) { try { e.proc.stdin.write('stop\n'); } catch {} setTimeout(() => { if (localProcs.has(server.id)) e.proc.kill('SIGTERM'); }, 20000); } return { ok: true }; }
  if (action === 'kill')    { const e = localProcs.get(server.id); if (e) e.proc.kill('SIGKILL'); return { ok: true }; }
  if (action === 'restart') { await serverAction(server, 'stop'); setTimeout(() => serverAction(server, 'start'), 3000); return { ok: true }; }
  if (action === 'command') { const e = localProcs.get(server.id); if (!e) return { ok: false, error: 'Not running.' }; try { e.proc.stdin.write(extraData.command + '\n'); return { ok: true }; } catch(err) { return { ok: false, error: err.message }; } }
  return { ok: false, error: 'Unknown action.' };
}

function getServerStats(server) {
  if (server.node_id && nodeManager.isConnected(server.node_id)) return null; // comes via WS
  const e = localProcs.get(server.id);
  if (!e) return { status: 'stopped', cpu: 0, ramUsed: 0, players: 0, maxPlayers: 20, tps: 20 };
  return { status: 'running', ...e.stats, uptime: Date.now() - e.startedAt };
}

function getServerLogs(server) {
  if (server.node_id && nodeManager.isConnected(server.node_id)) return '';
  const e = localProcs.get(server.id);
  return e ? e.logs.join('') : '';
}

// ═══════════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════════

// ── Auth ──────────────────────────────────────────────────────────
app.get('/',                (req, res) => res.redirect(req.session.userId ? '/dashboard' : '/auth/login'));
app.get('/auth/login',      (req, res) => res.render('auth/login',    { error: req.query.suspended ? 'Account suspended.' : null }));
app.get('/auth/register',   (req, res) => {
  if (db.getSetting('allowReg') === '0') return res.render('auth/login', { error: 'Registration is disabled.' });
  res.render('auth/register', { error: null });
});

app.post('/auth/login', loginLimit, async (req, res) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username=? OR email=?').get(username, username);
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.render('auth/login', { error: 'Invalid username or password.' });
  }
  if (user.suspended) return res.render('auth/login', { error: 'This account has been suspended.' });
  req.session.userId   = user.id;
  req.session.role     = user.role;
  req.session.username = user.username;
  db.prepare("UPDATE users SET last_login=strftime('%s','now') WHERE id=?").run(user.id);
  res.redirect('/dashboard');
});

app.post('/auth/register', async (req, res) => {
  if (db.getSetting('allowReg') === '0') return res.redirect('/auth/login');
  const { username, email, password, confirmPassword } = req.body;
  if (!username || !email || !password) return res.render('auth/register', { error: 'All fields required.' });
  if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) return res.render('auth/register', { error: 'Username: 3-20 chars, letters/numbers/underscore.' });
  if (password.length < 8) return res.render('auth/register', { error: 'Password min 8 characters.' });
  if (password !== confirmPassword) return res.render('auth/register', { error: 'Passwords do not match.' });
  if (db.prepare('SELECT id FROM users WHERE username=? OR email=?').get(username, email)) {
    return res.render('auth/register', { error: 'Username or email already taken.' });
  }
  const hash = await bcrypt.hash(password, 12);
  const slots = parseInt(db.getSetting('defaultSlots', '1'));
  db.prepare('INSERT INTO users(username,email,password,server_limit) VALUES(?,?,?,?)').run(username, email, hash, slots);
  res.redirect('/auth/login?registered=1');
});

app.get('/auth/logout', (req, res) => { req.session.destroy(); res.redirect('/auth/login'); });

// ── Dashboard ─────────────────────────────────────────────────────
app.get('/dashboard', requireAuth, (req, res) => {
  const servers = db.prepare(`
    SELECT DISTINCT s.*, n.name AS node_name FROM servers s
    LEFT JOIN nodes n ON n.id=s.node_id
    LEFT JOIN subusers su ON su.server_id=s.id
    WHERE s.owner_id=? OR su.user_id=?
    ORDER BY s.created_at DESC`).all(req.session.userId, req.session.userId);

  const liveServers = servers.map(s => ({
    ...s,
    stats: getServerStats(s),
    nodeConnected: s.node_id ? nodeManager.isConnected(s.node_id) : true
  }));

  const hostStats = {
    cpu: getCpuPercent(),
    mem: getMemStats(),
    disk: getDiskStats(),
    uptime: os.uptime()
  };

  res.render('dashboard', { servers: liveServers, hostStats, nodes: nodeManager.allNodes() });
});

// ── Notifications ─────────────────────────────────────────────────
app.get('/notifications', requireAuth, (req, res) => {
  const notifs = db.prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.session.userId);
  res.render('notifications', { notifications: notifs });
});
app.post('/notifications/mark-all-read', requireAuth, (req, res) => {
  db.prepare('UPDATE notifications SET read=1 WHERE user_id=?').run(req.session.userId);
  res.json({ ok: true });
});
app.post('/notifications/:id/read', requireAuth, (req, res) => {
  db.prepare('UPDATE notifications SET read=1 WHERE id=? AND user_id=?').run(req.params.id, req.session.userId);
  res.json({ ok: true });
});
app.delete('/notifications/clear-all', requireAuth, (req, res) => {
  db.prepare('DELETE FROM notifications WHERE user_id=?').run(req.session.userId);
  res.json({ ok: true });
});

// ── Profile ───────────────────────────────────────────────────────
app.get('/profile', requireAuth, (req, res) => res.render('profile/index'));

app.post('/profile/update', requireAuth, async (req, res) => {
  const { email, currentPassword, newPassword } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE id=?').get(req.session.userId);
  if (email && email !== user.email) {
    if (db.prepare('SELECT id FROM users WHERE email=? AND id!=?').get(email, user.id)) {
      return res.json({ ok: false, error: 'Email already in use.' });
    }
    db.prepare('UPDATE users SET email=? WHERE id=?').run(email, user.id);
  }
  if (newPassword) {
    if (!currentPassword || !(await bcrypt.compare(currentPassword, user.password))) {
      return res.json({ ok: false, error: 'Current password incorrect.' });
    }
    if (newPassword.length < 8) return res.json({ ok: false, error: 'New password min 8 chars.' });
    const hash = await bcrypt.hash(newPassword, 12);
    db.prepare('UPDATE users SET password=? WHERE id=?').run(hash, user.id);
  }
  res.json({ ok: true });
});

// ── Server Create ─────────────────────────────────────────────────
app.post('/servers/create', requireAuth, (req, res) => {
  const { name, server_type = 'paper', version = 'latest', node_id } = req.body;
  if (!name || !/^[a-zA-Z0-9 _-]{3,32}$/.test(name)) return res.json({ ok: false, error: 'Invalid name.' });

  const isAdmin = req.session.role === 'admin';
  if (!isAdmin) {
    const user  = db.prepare('SELECT server_limit FROM users WHERE id=?').get(req.session.userId);
    const count = db.prepare('SELECT COUNT(*) AS c FROM servers WHERE owner_id=?').get(req.session.userId).c;
    if (count >= user.server_limit) return res.json({ ok: false, error: 'Server slot limit reached.' });
  }

  const used = db.prepare('SELECT port FROM servers').all().map(r=>r.port);
  let port = 25565; while (used.includes(port)) port++;

  const ram  = parseInt(db.getSetting('defaultRam', '2048'));
  const disk = parseInt(db.getSetting('defaultDisk', '10240'));
  const uuid = crypto.randomUUID();
  const nodeId = (node_id && isAdmin) ? parseInt(node_id) : null;

  const r = db.prepare(
    `INSERT INTO servers(uuid,owner_id,node_id,name,server_type,version,ram,disk,port)
     VALUES(?,?,?,?,?,?,?,?,?)`
  ).run(uuid, req.session.userId, nodeId, name, server_type, version, ram, disk, port);

  // Ensure local dir
  if (!nodeId) fs.mkdirSync(path.join(__dirname, 'servers', String(r.lastInsertRowid)), { recursive: true });

  res.json({ ok: true, id: r.lastInsertRowid, port });
});

// ── Server Pages ──────────────────────────────────────────────────
app.get('/servers/:id/dashboard', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.redirect('/dashboard');
  const stats = getServerStats(server);
  const node  = server.node_id ? db.prepare('SELECT * FROM nodes WHERE id=?').get(server.node_id) : null;
  res.render('servers/dashboard', { server, stats, node, activePage: 'dashboard' });
});

app.get('/servers/:id/console', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.redirect('/dashboard');
  res.render('servers/console', { server, activePage: 'console' });
});

app.get('/servers/:id/files', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.redirect('/dashboard');
  const relPath = req.query.path || '.';
  let files = [];
  let error = null;
  if (!server.node_id) {
    try {
      const target = safeServerPath(server.id, relPath);
      if (!fs.existsSync(target)) fs.mkdirSync(target, { recursive: true });
      files = fs.readdirSync(target, { withFileTypes: true }).map(e => {
        const st = fs.statSync(path.join(target, e.name));
        return { name: e.name, isDir: e.isDirectory(), size: st.size, modified: st.mtimeMs };
      });
      files.sort((a,b) => (b.isDir - a.isDir) || a.name.localeCompare(b.name));
    } catch(e) { error = e.message; }
  }
  res.render('servers/files', { server, files, currentPath: relPath, error, activePage: 'files' });
});

app.get('/servers/:id/backups', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.redirect('/dashboard');
  const backups = db.prepare('SELECT * FROM backups WHERE server_id=? ORDER BY created_at DESC').all(server.id);
  res.render('servers/backups', { server, backups, activePage: 'backups' });
});

app.get('/servers/:id/subusers', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.redirect('/dashboard');
  const subusers = db.prepare('SELECT su.*,u.username,u.email FROM subusers su JOIN users u ON u.id=su.user_id WHERE su.server_id=?').all(server.id);
  res.render('servers/subusers', { server, subusers, activePage: 'subusers' });
});

app.get('/servers/:id/settings', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.redirect('/dashboard');
  res.render('servers/settings', { server, activePage: 'settings' });
});

app.get('/servers/:id/startup', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.redirect('/dashboard');
  res.render('servers/startup', { server, activePage: 'startup' });
});

app.get('/servers/:id/players', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.redirect('/dashboard');
  res.render('servers/players', { server, activePage: 'players' });
});

// ── Server Actions ────────────────────────────────────────────────
for (const action of ['start','stop','kill','restart']) {
  app.post(`/servers/:id/${action}`, requireAuth, async (req, res) => {
    const server = getServer(req.params.id, req.session.userId, req.session.role);
    if (!server) return res.json({ ok: false, error: 'Not found.' });
    if (server.suspended) return res.json({ ok: false, error: 'Server suspended.' });
    const result = await serverAction(server, action);
    if (result.ok && action === 'start') db.prepare("UPDATE servers SET status='starting' WHERE id=?").run(server.id);
    if (result.ok && action === 'stop')  db.prepare("UPDATE servers SET status='stopping' WHERE id=?").run(server.id);
    if (result.ok && action === 'kill')  db.prepare("UPDATE servers SET status='stopped'  WHERE id=?").run(server.id);
    res.json(result);
  });
}

app.post('/servers/:id/command', requireAuth, async (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false, error: 'Not found.' });
  const { command } = req.body;
  if (!command || command.length > 256) return res.json({ ok: false, error: 'Invalid command.' });
  const result = await serverAction(server, 'command', { command });
  res.json(result);
});

// Console logs API
app.get('/servers/:id/logs', requireAuth, async (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ logs: '' });
  if (server.node_id && nodeManager.isConnected(server.node_id)) {
    try { const r = await nodeManager.send(server.node_id, { type: 'logs', serverId: server.id }); return res.json({ logs: r.logs || '' }); }
    catch { return res.json({ logs: '' }); }
  }
  res.json({ logs: getServerLogs(server) });
});

// Stats API
app.get('/servers/:id/stats', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({});
  res.json(getServerStats(server) || {});
});

// ── File Manager API ───────────────────────────────────────────────
app.get('/servers/:id/files/view', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.status(404).send('Not found');
  try {
    const target = safeServerPath(server.id, req.query.path);
    if (fs.statSync(target).size > 2*1024*1024) return res.status(413).send('File too large.');
    res.json({ content: fs.readFileSync(target, 'utf8') });
  } catch(e) { res.status(400).json({ error: e.message }); }
});

app.post('/servers/:id/files/save', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  try {
    const target = safeServerPath(server.id, req.body.path);
    fs.writeFileSync(target, req.body.content || '', 'utf8');
    res.json({ ok: true });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

app.post('/servers/:id/files/upload', requireAuth, upload.single('file'), (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server || !req.file) return res.json({ ok: false, error: 'No file.' });
  try {
    const dir  = safeServerPath(server.id, req.query.path || '.');
    const dest = path.join(dir, sanitize(req.file.originalname));
    fs.mkdirSync(dir, { recursive: true });
    fs.renameSync(req.file.path, dest);
    res.json({ ok: true });
  } catch(e) {
    try { fs.unlinkSync(req.file.path); } catch {}
    res.json({ ok: false, error: e.message });
  }
});

app.get('/servers/:id/files/download', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.status(404).send('Not found');
  try {
    const target = safeServerPath(server.id, req.query.path);
    if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) return res.status(404).send('Not found');
    res.download(target, path.basename(target));
  } catch(e) { res.status(400).send(e.message); }
});

app.post('/servers/:id/files/rename', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  try {
    const src = safeServerPath(server.id, req.body.oldPath);
    const dst = safeServerPath(server.id, req.body.newPath);
    fs.renameSync(src, dst);
    res.json({ ok: true });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

app.post('/servers/:id/files/delete', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  try {
    const target = safeServerPath(server.id, req.body.path);
    const root   = path.join(__dirname, 'servers', String(server.id));
    if (target === root) return res.json({ ok: false, error: 'Cannot delete root.' });
    fs.rmSync(target, { recursive: true, force: true });
    res.json({ ok: true });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

app.post('/servers/:id/files/create-folder', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  try {
    const target = safeServerPath(server.id, (req.body.currentPath||'') + '/' + sanitize(req.body.folderName||'newfolder'));
    fs.mkdirSync(target, { recursive: true });
    res.json({ ok: true });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

app.post('/servers/:id/files/zip', requireAuth, async (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  try {
    const src  = safeServerPath(server.id, req.body.path);
    const out  = src + '.tar.gz';
    const { createTarStream } = require('./services/tar');
    await pipeline(createTarStream(src), zlib.createGzip(), fs.createWriteStream(out));
    res.json({ ok: true, filename: path.basename(out) });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

// ── Backup routes ─────────────────────────────────────────────────
app.post('/servers/:id/backups/create', requireAuth, async (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  try {
    const { createTarStream } = require('./services/tar');
    const BACKUPS_DIR = path.join(__dirname, 'backups', String(server.id));
    fs.mkdirSync(BACKUPS_DIR, { recursive: true });
    const ts   = new Date().toISOString().replace(/[:.]/g,'-');
    const file = `${server.name.replace(/[^a-zA-Z0-9_-]/g,'_')}_${ts}.tar.gz`;
    const dest = path.join(BACKUPS_DIR, file);
    const src  = path.join(__dirname, 'servers', String(server.id));
    await pipeline(createTarStream(src), zlib.createGzip({ level:6 }), fs.createWriteStream(dest));
    const size = fs.statSync(dest).size;
    db.prepare('INSERT INTO backups(server_id,filename,size_bytes) VALUES(?,?,?)').run(server.id, file, size);
    res.json({ ok: true, filename: file, sizeBytes: size });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

app.post('/servers/:id/backups/delete', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  const backup = db.prepare('SELECT * FROM backups WHERE id=? AND server_id=?').get(req.body.backupId, server.id);
  if (!backup) return res.json({ ok: false, error: 'Not found.' });
  const fp = path.join(__dirname, 'backups', String(server.id), backup.filename);
  if (fs.existsSync(fp)) fs.unlinkSync(fp);
  db.prepare('DELETE FROM backups WHERE id=?').run(backup.id);
  res.json({ ok: true });
});

app.get('/servers/:id/backups/download/:filename', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.status(404).send('Not found');
  const fp = path.join(__dirname, 'backups', String(server.id), sanitize(req.params.filename));
  if (!fs.existsSync(fp)) return res.status(404).send('Not found');
  res.download(fp);
});

// ── Subusers ───────────────────────────────────────────────────────
app.post('/servers/:id/subusers/add', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server || (server.owner_id !== req.session.userId && req.session.role !== 'admin')) return res.json({ ok: false });
  const u = db.prepare('SELECT id FROM users WHERE username=? OR email=?').get(req.body.identifier, req.body.identifier);
  if (!u) return res.json({ ok: false, error: 'User not found.' });
  if (u.id === server.owner_id) return res.json({ ok: false, error: 'Cannot add owner.' });
  try {
    db.prepare('INSERT OR REPLACE INTO subusers(server_id,user_id,perms) VALUES(?,?,?)').run(server.id, u.id, '[]');
    res.json({ ok: true });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

app.post('/servers/:id/subusers/remove', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  db.prepare('DELETE FROM subusers WHERE server_id=? AND user_id=?').run(server.id, req.body.userId);
  res.json({ ok: true });
});

// ── Server Settings ────────────────────────────────────────────────
app.post('/servers/:id/settings/update', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  const { name, version, server_type } = req.body;
  if (name && /^[a-zA-Z0-9 _-]{3,32}$/.test(name)) db.prepare('UPDATE servers SET name=? WHERE id=?').run(name, server.id);
  if (version) db.prepare('UPDATE servers SET version=? WHERE id=?').run(version, server.id);
  if (server_type) db.prepare('UPDATE servers SET server_type=? WHERE id=?').run(server_type, server.id);
  res.json({ ok: true });
});

app.post('/servers/:id/startup/update', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  const { startup_cmd } = req.body;
  if (startup_cmd) db.prepare('UPDATE servers SET startup_cmd=? WHERE id=?').run(startup_cmd, server.id);
  res.json({ ok: true });
});

app.post('/servers/:id/delete', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  if (localProcs.has(server.id)) return res.json({ ok: false, error: 'Stop server first.' });
  db.prepare('DELETE FROM servers WHERE id=?').run(server.id);
  res.json({ ok: true });
});

// ── Server Properties ────────────────────────────────────────────
app.get('/servers/:id/properties', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.redirect('/dashboard');
  let props = {};
  try {
    const fp = safeServerPath(server.id, 'server.properties');
    if (fs.existsSync(fp)) {
      const lines = fs.readFileSync(fp, 'utf8').split('\n');
      for (const line of lines) {
        if (line.startsWith('#') || !line.includes('=')) continue;
        const [k,...v] = line.split('=');
        props[k.trim()] = v.join('=').trim();
      }
    }
  } catch {}
  res.render('servers/properties', { server, props, activePage: 'properties' });
});

app.post('/servers/:id/properties/save', requireAuth, (req, res) => {
  const server = getServer(req.params.id, req.session.userId, req.session.role);
  if (!server) return res.json({ ok: false });
  try {
    const fp = safeServerPath(server.id, 'server.properties');
    const lines = Object.entries(req.body).map(([k,v]) => `${k}=${v}`);
    fs.writeFileSync(fp, lines.join('\n') + '\n', 'utf8');
    res.json({ ok: true });
  } catch(e) { res.json({ ok: false, error: e.message }); }
});

// ══════════════════════════════════════════════════════════════════
// ADMIN ROUTES
// ══════════════════════════════════════════════════════════════════
app.get('/admin', requireAdmin, (req, res) => {
  const stats = {
    users:   db.prepare('SELECT COUNT(*) AS c FROM users').get().c,
    servers: db.prepare('SELECT COUNT(*) AS c FROM servers').get().c,
    running: db.prepare("SELECT COUNT(*) AS c FROM servers WHERE status='running'").get().c,
    nodes:   db.prepare('SELECT COUNT(*) AS c FROM nodes').get().c,
  };
  res.render('admin/index', { stats, nodes: nodeManager.allNodes() });
});

app.get('/admin/users', requireAdmin, (req, res) => {
  const search = req.query.q ? `%${req.query.q}%` : '%';
  const users  = db.prepare('SELECT * FROM users WHERE username LIKE ? OR email LIKE ? ORDER BY created_at DESC LIMIT 100').all(search, search);
  res.render('admin/users', { users });
});

app.post('/admin/users/:id/update', requireAdmin, (req, res) => {
  const { suspended, role, server_limit } = req.body;
  if (suspended !== undefined) db.prepare('UPDATE users SET suspended=? WHERE id=?').run(suspended ? 1 : 0, req.params.id);
  if (role && ['user','admin'].includes(role)) db.prepare('UPDATE users SET role=? WHERE id=?').run(role, req.params.id);
  if (server_limit) db.prepare('UPDATE users SET server_limit=? WHERE id=?').run(parseInt(server_limit)||1, req.params.id);
  res.json({ ok: true });
});

app.post('/admin/users/:id/delete', requireAdmin, (req, res) => {
  if (parseInt(req.params.id) === req.session.userId) return res.json({ ok: false, error: 'Cannot delete yourself.' });
  db.prepare('DELETE FROM users WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

app.get('/admin/servers', requireAdmin, (req, res) => {
  const servers = db.prepare('SELECT s.*,u.username AS owner,n.name AS node_name FROM servers s LEFT JOIN users u ON u.id=s.owner_id LEFT JOIN nodes n ON n.id=s.node_id ORDER BY s.created_at DESC').all();
  res.render('admin/servers', { servers });
});

app.post('/admin/servers/:id/update', requireAdmin, (req, res) => {
  const { ram, cpu, disk, suspended } = req.body;
  const updates = [];
  const vals    = [];
  if (ram !== undefined)       { updates.push('ram=?');       vals.push(parseInt(ram)||2048); }
  if (cpu !== undefined)       { updates.push('cpu=?');       vals.push(parseInt(cpu)||100); }
  if (disk !== undefined)      { updates.push('disk=?');      vals.push(parseInt(disk)||10240); }
  if (suspended !== undefined) { updates.push('suspended=?'); vals.push(suspended ? 1 : 0); }
  if (updates.length) { vals.push(req.params.id); db.prepare(`UPDATE servers SET ${updates.join(',')} WHERE id=?`).run(...vals); }
  res.json({ ok: true });
});

// ── Node Management (Admin) ────────────────────────────────────────
app.get('/admin/nodes', requireAdmin, (req, res) => {
  const nodes = db.prepare('SELECT * FROM nodes ORDER BY created_at DESC').all();
  const nodesWithStatus = nodes.map(n => ({ ...n, status: nodeManager.getStatus(n.id) }));
  res.render('admin/nodes', { nodes: nodesWithStatus });
});

app.post('/admin/nodes/create', requireAdmin, (req, res) => {
  const { name, fqdn, port = 8080, token, location, memory_mb = 2048, disk_mb = 20480 } = req.body;
  if (!name || !fqdn || !token) return res.json({ ok: false, error: 'name, fqdn, token required.' });
  const wsUrl = `ws://${fqdn}:${port}`;
  const r = db.prepare(
    'INSERT INTO nodes(name,fqdn,ws_url,token,location,memory_mb,disk_mb) VALUES(?,?,?,?,?,?,?)'
  ).run(name, fqdn, wsUrl, token, location||'', parseInt(memory_mb), parseInt(disk_mb));
  nodeManager.connect(r.lastInsertRowid, wsUrl, token);
  res.json({ ok: true, id: r.lastInsertRowid });
});

app.post('/admin/nodes/:id/delete', requireAdmin, (req, res) => {
  const node = db.prepare('SELECT * FROM nodes WHERE id=?').get(req.params.id);
  if (!node) return res.json({ ok: false });
  nodeManager.disconnect(node.id);
  db.prepare('DELETE FROM nodes WHERE id=?').run(node.id);
  res.json({ ok: true });
});

app.get('/admin/nodes/:id/status', requireAdmin, (req, res) => {
  res.json({ status: nodeManager.getStatus(req.params.id) });
});

// ── Panel Settings ─────────────────────────────────────────────────
app.get('/admin/settings', requireAdmin, (req, res) => {
  res.render('admin/settings', { cfg: db.allSettings() });
});

app.post('/admin/settings', requireAdmin, upload.fields([
  { name: 'headerIcon', maxCount: 1 },
  { name: 'favicon',   maxCount: 1 }
]), (req, res) => {
  const allowed = ['panelName','allowReg','defaultRam','defaultDisk','defaultCpu','defaultSlots','maintenance','videoBackground'];
  for (const key of allowed) {
    if (req.body[key] !== undefined) db.setSetting(key, req.body[key]);
  }
  // Handle file uploads
  if (req.files && req.files.headerIcon) {
    const f = req.files.headerIcon[0];
    const dest = path.join(__dirname, 'public', 'header-icon.jpg');
    fs.renameSync(f.path, dest);
  }
  if (req.files && req.files.favicon) {
    const f = req.files.favicon[0];
    const dest = path.join(__dirname, 'public', 'favicon.ico');
    fs.renameSync(f.path, dest);
  }
  req.flash('success', 'Settings saved.');
  res.redirect('/admin/settings');
});

// ── System stats API ───────────────────────────────────────────────
app.get('/api/system-stats', requireAuth, (req, res) => {
  res.json({ cpu: getCpuPercent(), mem: getMemStats(), disk: getDiskStats(), uptime: os.uptime(), load: os.loadavg() });
});

// ── System stats helpers ───────────────────────────────────────────
let _lastCpus = os.cpus();
function getCpuPercent() {
  const cpus = os.cpus(); let idle=0, total=0;
  for (let i=0;i<cpus.length;i++) {
    const p=_lastCpus[i]?_lastCpus[i].times:cpus[i].times, c=cpus[i].times;
    const pt=Object.values(p).reduce((a,b)=>a+b,0), ct=Object.values(c).reduce((a,b)=>a+b,0);
    idle+=c.idle-p.idle; total+=ct-pt;
  }
  _lastCpus=cpus; return total>0?Math.round((1-idle/total)*1000)/10:0;
}
function getMemStats() {
  const t=os.totalmem(),f=os.freemem(),u=t-f;
  return { totalMb:Math.round(t/1024/1024), usedMb:Math.round(u/1024/1024), percent:Math.round(u/t*1000)/10 };
}
function getDiskStats() {
  try { const s=fs.statfsSync('/'),t=s.blocks*s.bsize,fr=s.bfree*s.bsize,u=t-fr; return { totalMb:Math.round(t/1024/1024), usedMb:Math.round(u/1024/1024), percent:t>0?Math.round(u/t*1000)/10:0 }; }
  catch { return { totalMb:0, usedMb:0, percent:0 }; }
}

// ── Boot: connect saved nodes ──────────────────────────────────────
function bootNodes() {
  const nodes = db.prepare('SELECT * FROM nodes WHERE enabled=1').all();
  for (const node of nodes) {
    console.log(`[Panel] Connecting to node: ${node.name} (${node.ws_url})`);
    nodeManager.connect(node.id, node.ws_url, node.token);
  }
}

// ── Admin seed ────────────────────────────────────────────────────
async function seedAdmin() {
  const exists = db.prepare("SELECT id FROM users WHERE role='admin'").get();
  if (!exists) {
    const hash = await bcrypt.hash('Admin@123', 12);
    db.prepare("INSERT INTO users(username,email,password,role,server_limit) VALUES('admin','admin@mcpanel.local',?,'admin',999)").run(hash);
    console.log('\n[Panel] Default admin created → username: admin | password: Admin@123\n[Panel] ⚠️  Change password immediately!\n');
  }
}

// ── Start ─────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
seedAdmin().then(() => {
  bootNodes();
  server.listen(PORT, '0.0.0.0', () => {
    console.log(`\n✅ MC Panel running → http://localhost:${PORT}`);
    console.log(`   Local servers dir: ${path.join(__dirname, 'servers')}`);
    console.log(`   Node.js: ${process.version}\n`);
  });
});
