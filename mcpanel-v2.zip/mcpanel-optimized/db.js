/**
 * better-sqlite3 wrapper — synchronous, WAL mode, 3x faster than async sqlite3
 * SQLite3 এর বদলে better-sqlite3 — কম RAM, বেশি fast
 */
'use strict';

const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'database', 'panel.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('synchronous = NORMAL');
db.pragma('cache_size = -8000');   // 8MB cache
db.pragma('temp_store = MEMORY');

// ── Schema ────────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT    UNIQUE NOT NULL,
    email         TEXT    UNIQUE NOT NULL,
    password      TEXT    NOT NULL,
    role          TEXT    NOT NULL DEFAULT 'user',
    suspended     INTEGER NOT NULL DEFAULT 0,
    profile_pic   TEXT,
    server_limit  INTEGER NOT NULL DEFAULT 1,
    created_at    INTEGER NOT NULL DEFAULT (strftime('%s','now')),
    last_login    INTEGER
  );

  CREATE TABLE IF NOT EXISTS nodes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT    NOT NULL,
    fqdn       TEXT    NOT NULL,
    ws_url     TEXT    NOT NULL,
    token      TEXT    NOT NULL,
    location   TEXT    DEFAULT '',
    memory_mb  INTEGER DEFAULT 2048,
    disk_mb    INTEGER DEFAULT 20480,
    enabled    INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
  );

  CREATE TABLE IF NOT EXISTS servers (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid        TEXT    UNIQUE NOT NULL,
    owner_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    node_id     INTEGER REFERENCES nodes(id) ON DELETE SET NULL,
    name        TEXT    NOT NULL,
    server_type TEXT    NOT NULL DEFAULT 'paper',
    version     TEXT    NOT NULL DEFAULT 'latest',
    ram         INTEGER NOT NULL DEFAULT 2048,
    cpu         INTEGER NOT NULL DEFAULT 100,
    disk        INTEGER NOT NULL DEFAULT 10240,
    port        INTEGER NOT NULL,
    status      TEXT    NOT NULL DEFAULT 'stopped',
    suspended   INTEGER NOT NULL DEFAULT 0,
    startup_cmd TEXT    DEFAULT 'java -Xms128M -Xmx{ram}M -jar server.jar nogui',
    created_at  INTEGER NOT NULL DEFAULT (strftime('%s','now'))
  );

  CREATE TABLE IF NOT EXISTS subusers (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id  INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    user_id    INTEGER NOT NULL REFERENCES users(id)   ON DELETE CASCADE,
    perms      TEXT    NOT NULL DEFAULT '[]',
    UNIQUE(server_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS backups (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    server_id  INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
    filename   TEXT    NOT NULL,
    size_bytes INTEGER NOT NULL DEFAULT 0,
    node_id    INTEGER,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER REFERENCES users(id) ON DELETE CASCADE,
    category   TEXT    NOT NULL DEFAULT 'general',
    title      TEXT    NOT NULL,
    message    TEXT    NOT NULL,
    read       INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
  );

  CREATE TABLE IF NOT EXISTS panel_settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS file_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER,
    server_id  INTEGER,
    action     TEXT    NOT NULL,
    file_path  TEXT,
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
  );

  CREATE INDEX IF NOT EXISTS idx_servers_owner ON servers(owner_id);
  CREATE INDEX IF NOT EXISTS idx_servers_node  ON servers(node_id);
  CREATE INDEX IF NOT EXISTS idx_notifs_user   ON notifications(user_id);
`);

// ── Default settings ──────────────────────────────────────────────
const defaults = {
  panelName:     'MC Panel',
  headerIcon:    '/header-icon.jpg',
  faviconUrl:    '/favicon.ico',
  allowReg:      '1',
  defaultRam:    '2048',
  defaultDisk:   '10240',
  defaultCpu:    '100',
  defaultSlots:  '1',
  videoBackground: '',
  maintenance:   '0'
};
const upsertSetting = db.prepare('INSERT OR IGNORE INTO panel_settings(key,value) VALUES(?,?)');
for (const [k, v] of Object.entries(defaults)) upsertSetting.run(k, v);

// ── Helper functions (replaces async sqlite3 callbacks) ───────────
db.getSetting = (key, fallback = '') => {
  const row = db.prepare('SELECT value FROM panel_settings WHERE key=?').get(key);
  return row ? row.value : fallback;
};
db.setSetting = (key, value) => {
  db.prepare('INSERT INTO panel_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, String(value));
};
db.allSettings = () => {
  const rows = db.prepare('SELECT key,value FROM panel_settings').all();
  return Object.fromEntries(rows.map(r => [r.key, r.value]));
};

module.exports = db;
