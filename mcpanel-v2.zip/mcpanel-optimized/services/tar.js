'use strict';
const fs   = require('fs');
const path = require('path');
const { Readable } = require('stream');

function createTarStream(srcDir) {
  const files = [];
  function walk(dir, base) {
    if (!fs.existsSync(dir)) return;
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, e.name);
      const rel  = base ? `${base}/${e.name}` : e.name;
      if (e.isDirectory()) { files.push({ full, rel: rel+'/', isDir:true }); walk(full, rel); }
      else files.push({ full, rel, isDir:false });
    }
  }
  walk(srcDir, '');
  let idx = 0;
  return new Readable({
    read() {
      if (idx >= files.length) { this.push(Buffer.alloc(1024)); this.push(null); return; }
      const item = files[idx++];
      const stat = fs.statSync(item.full);
      const hdr  = Buffer.alloc(512);
      hdr.write(item.rel.slice(0,100), 0, 100);
      hdr.write((item.isDir?'755':'644').padStart(7,'0')+'\0', 100, 8);
      hdr.write('0000000\0', 108, 8); hdr.write('0000000\0', 116, 8);
      const size = item.isDir ? 0 : stat.size;
      hdr.write(size.toString(8).padStart(11,'0')+' ', 124, 12);
      hdr.write(Math.floor(stat.mtimeMs/1000).toString(8).padStart(11,'0')+' ', 136, 12);
      hdr.write('        ', 148, 8);
      hdr.write(item.isDir ? '5' : '0', 156, 1);
      hdr.write('ustar', 257, 5);
      let chk = 0; for (let i=0;i<512;i++) chk+=hdr[i];
      hdr.write(chk.toString(8).padStart(6,'0')+'\0 ', 148, 8);
      this.push(hdr);
      if (!item.isDir) {
        const content = fs.readFileSync(item.full);
        this.push(content);
        const pad = 512 - (content.length % 512);
        if (pad < 512) this.push(Buffer.alloc(pad));
      }
    }
  });
}
module.exports = { createTarStream };
