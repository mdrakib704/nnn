'use strict';

const USERNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const SERVERNAME_RE = /^[a-zA-Z0-9 _-]{3,32}$/;

function isValidUsername(v) {
  return typeof v === 'string' && USERNAME_RE.test(v);
}

function isValidEmail(v) {
  return typeof v === 'string' && EMAIL_RE.test(v) && v.length <= 255;
}

function isValidPassword(v) {
  return typeof v === 'string' && v.length >= 8 && v.length <= 128;
}

function isValidServerName(v) {
  return typeof v === 'string' && SERVERNAME_RE.test(v);
}

function sanitizeString(v, maxLen = 500) {
  if (typeof v !== 'string') return '';
  return v
    .replace(/[<>]/g, '')
    .slice(0, maxLen)
    .trim();
}

function isSafePathSegment(v) {
  if (typeof v !== 'string' || v.length === 0) return false;
  if (v.includes('..') || v.includes('\0')) return false;
  if (v.startsWith('/') || /^[a-zA-Z]:\\/.test(v)) return false;
  return true;
}

module.exports = {
  isValidUsername,
  isValidEmail,
  isValidPassword,
  isValidServerName,
  sanitizeString,
  isSafePathSegment
};
