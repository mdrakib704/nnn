'use strict';

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcrypt');
const config = require('../config.json');

const dbPath = path.resolve(__dirname, '..', config.dbFile.replace('./', ''));
fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('synchronous = NORMAL');

function migrate() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user',
      coins INTEGER NOT NULL DEFAULT 0,
      suspended INTEGER NOT NULL DEFAULT 0,
      two_fa_secret TEXT,
      two_fa_enabled INTEGER NOT NULL DEFAULT 0,
      reset_token TEXT,
      reset_token_expires INTEGER,
      server_slots INTEGER NOT NULL DEFAULT 1,
      referral_code TEXT UNIQUE,
      referred_by INTEGER,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
      last_login_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      refresh_token TEXT NOT NULL,
      user_agent TEXT,
      ip TEXT,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
      expires_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS servers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      uuid TEXT UNIQUE NOT NULL,
      owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      software TEXT NOT NULL DEFAULT 'paper',
      version TEXT NOT NULL DEFAULT 'latest',
      java_version TEXT NOT NULL DEFAULT 'java17',
      ram_mb INTEGER NOT NULL DEFAULT 3072,
      cpu_percent INTEGER NOT NULL DEFAULT 100,
      disk_mb INTEGER NOT NULL DEFAULT 10240,
      port INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'stopped',
      suspended INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS backups (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
      filename TEXT NOT NULL,
      size_bytes INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS backup_schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      server_id INTEGER NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
      cron_expr TEXT NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      amount INTEGER NOT NULL,
      type TEXT NOT NULL,
      description TEXT,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS promo_codes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT UNIQUE NOT NULL,
      coin_value INTEGER NOT NULL,
      max_uses INTEGER NOT NULL DEFAULT 1,
      uses INTEGER NOT NULL DEFAULT 0,
      expires_at INTEGER,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS promo_redemptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      promo_id INTEGER NOT NULL REFERENCES promo_codes(id) ON DELETE CASCADE,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      redeemed_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
      UNIQUE(promo_id, user_id)
    );

    CREATE TABLE IF NOT EXISTS shop_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      label TEXT NOT NULL,
      amount INTEGER NOT NULL,
      price_coins INTEGER NOT NULL,
      enabled INTEGER NOT NULL DEFAULT 1
    );

    CREATE TABLE IF NOT EXISTS api_keys (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      key_hash TEXT NOT NULL,
      key_prefix TEXT NOT NULL,
      permissions TEXT NOT NULL DEFAULT '[]',
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now')),
      last_used_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS ads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      coin_reward INTEGER NOT NULL DEFAULT 0,
      closeable INTEGER NOT NULL DEFAULT 1,
      frequency_minutes INTEGER NOT NULL DEFAULT 60,
      start_at INTEGER,
      end_at INTEGER,
      enabled INTEGER NOT NULL DEFAULT 1,
      impressions INTEGER NOT NULL DEFAULT 0,
      clicks INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      level TEXT NOT NULL DEFAULT 'info',
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      read INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      action TEXT NOT NULL,
      details TEXT,
      ip TEXT,
      created_at INTEGER NOT NULL DEFAULT (strftime('%s','now'))
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_servers_owner ON servers(owner_id);
    CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id);
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);
  `);

  const defaultSettings = {
    theme: 'dark-glass',
    background_video: '',
    background_loop: '1',
    background_mute: '1',
    background_blur: '0',
    background_brightness: '100',
    background_opacity: '100',
    background_overlay: '40',
    site_name: 'NX Panel',
    daily_reward_coins: '50',
    referral_reward_coins: '100'
  };
  const insertSetting = db.prepare(
    'INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)'
  );
  for (const [k, v] of Object.entries(defaultSettings)) {
    insertSetting.run(k, v);
  }

  const adminCount = db
    .prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'admin'")
    .get().c;

  if (adminCount === 0) {
    const { username, email, password } = config.defaultAdmin;
    const hash = bcrypt.hashSync(password, config.bcryptRounds);
    const refCode = require('crypto').randomBytes(6).toString('hex');
    db.prepare(
      `INSERT INTO users (username, email, password_hash, role, coins, server_slots, referral_code)
       VALUES (?, ?, ?, 'admin', 1000, 999, ?)`
    ).run(username, email, hash, refCode);
    console.log(
      `[NX Panel] Default admin account created -> username: ${username} | password: ${password} (CHANGE THIS IMMEDIATELY)`
    );
  }

  const shopCount = db.prepare('SELECT COUNT(*) AS c FROM shop_items').get().c;
  if (shopCount === 0) {
    const items = [
      ['ram', '+1024 MB RAM', 1024, 200],
      ['cpu', '+25% CPU', 25, 150],
      ['disk', '+5120 MB Storage', 5120, 100],
      ['slot', '+1 Server Slot', 1, 500]
    ];
    const insertItem = db.prepare(
      'INSERT INTO shop_items (type, label, amount, price_coins) VALUES (?, ?, ?, ?)'
    );
    for (const item of items) insertItem.run(...item);
  }
}

migrate();

module.exports = db;
