'use strict';

const path = require('path');
const fs = require('fs');
const Fastify = require('fastify');
const config = require('./config.json');

// ── Ensure upload/background dirs exist ──────────────────────────────────────
['uploads', 'backgrounds', 'backups', 'servers', 'logs'].forEach((d) =>
  fs.mkdirSync(path.join(__dirname, d), { recursive: true })
);

// ── Bootstrap DB (runs migrations + admin seed) ───────────────────────────────
require('./database/db');

// ── Build Fastify instance ────────────────────────────────────────────────────
const app = Fastify({
  logger: {
    level: process.env.LOG_LEVEL || 'info',
    transport:
      process.env.NODE_ENV !== 'production'
        ? { target: 'pino-pretty', options: { translateTime: true, ignore: 'pid,hostname' } }
        : undefined
  },
  trustProxy: true,
  bodyLimit: 50 * 1024 * 1024 // 50 MB (for file uploads via JSON; multipart bypasses this)
});

async function start() {
  // ── Plugins ────────────────────────────────────────────────────────────────
  await app.register(require('@fastify/cookie'));

  await app.register(require('@fastify/cors'), {
    origin: true,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS']
  });

  await app.register(require('@fastify/rate-limit'), {
    max: config.rateLimit.max,
    timeWindow: config.rateLimit.timeWindow
  });

  await app.register(require('@fastify/multipart'), {
    limits: {
      fileSize: 500 * 1024 * 1024, // 500 MB max upload
      files: 1
    }
  });

  // Static files: public dir (HTML/CSS/JS) and backgrounds/uploads
  await app.register(require('@fastify/static'), {
    root: path.join(__dirname, 'public'),
    prefix: '/'
  });

  await app.register(require('@fastify/static'), {
    root: path.join(__dirname, 'backgrounds'),
    prefix: '/backgrounds/',
    decorateReply: false
  });

  await app.register(require('@fastify/static'), {
    root: path.join(__dirname, 'uploads'),
    prefix: '/uploads/',
    decorateReply: false
  });

  // WebSocket support
  await app.register(require('@fastify/websocket'));

  // ── Auth decorators ────────────────────────────────────────────────────────
  await app.register(require('./auth/middleware'));

  // ── Route plugins ──────────────────────────────────────────────────────────
  await app.register(require('./auth/routes'));
  await app.register(require('./api/v1/servers'));
  await app.register(require('./api/v1/files'));
  await app.register(require('./api/v1/coins'));
  await app.register(require('./api/v1/user'));
  await app.register(require('./api/v1/stats'));
  await app.register(require('./api/v1/admin'));

  // ── WebSocket endpoint ─────────────────────────────────────────────────────
  const { wsHandler } = require('./websocket/wsHandler');
  app.get('/ws', { websocket: true }, wsHandler);

  // ── SPA fallback: non-API routes serve index.html ─────────────────────────
  app.setNotFoundHandler((request, reply) => {
    if (!request.url.startsWith('/api/') && !request.url.startsWith('/ws')) {
      return reply.sendFile('index.html');
    }
    return reply.code(404).send({ error: 'Not found.' });
  });

  // ── Global error handler ───────────────────────────────────────────────────
  app.setErrorHandler((error, request, reply) => {
    app.log.error(error);
    const status = error.statusCode || 500;
    reply.code(status).send({ error: error.message || 'Internal server error.' });
  });

  // ── Cron: backup schedules + session cleanup ───────────────────────────────
  const cron = require('node-cron');
  const db = require('./database/db');
  const backupService = require('./services/backupService');

  // Clean expired sessions every hour
  cron.schedule('0 * * * *', () => {
    const now = Math.floor(Date.now() / 1000);
    db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(now);
  });

  // Run all enabled backup schedules
  const schedules = db.prepare('SELECT * FROM backup_schedules WHERE enabled = 1').all();
  for (const schedule of schedules) {
    if (!cron.validate(schedule.cron_expr)) continue;
    cron.schedule(schedule.cron_expr, async () => {
      const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(schedule.server_id);
      if (server) {
        try {
          await backupService.createBackup(server);
          app.log.info(`[NX Panel] Scheduled backup completed for server: ${server.name}`);
        } catch (err) {
          app.log.error(`[NX Panel] Scheduled backup failed: ${err.message}`);
        }
      }
    });
  }

  // ── Listen ─────────────────────────────────────────────────────────────────
  await app.listen({ port: config.port, host: config.host });
  console.log(`\n🟢 NX Panel is running → http://localhost:${config.port}\n`);
}

start().catch((err) => {
  console.error('[NX Panel] Fatal startup error:', err);
  process.exit(1);
});
