'use strict';

const bcrypt = require('bcrypt');
const crypto = require('crypto');
const db = require('../../database/db');
const config = require('../../config.json');
const { isValidPassword, isValidEmail } = require('../../utils/validate');
const { audit } = require('../../utils/audit');
const { deleteAllSessionsForUser } = require('../../auth/tokens');

async function userRoutes(fastify) {
  fastify.addHook('preHandler', fastify.authenticate);

  fastify.get('/api/v1/user/me', async (request) => {
    const user = db
      .prepare(
        'SELECT id, username, email, role, coins, suspended, server_slots, referral_code, created_at, last_login_at FROM users WHERE id = ?'
      )
      .get(request.user.id);
    return user;
  });

  fastify.patch('/api/v1/user/me', async (request, reply) => {
    const { email, currentPassword, newPassword } = request.body || {};
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(request.user.id);

    if (email && email !== user.email) {
      if (!isValidEmail(email)) return reply.code(400).send({ error: 'Invalid email.' });
      const existing = db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(email, user.id);
      if (existing) return reply.code(409).send({ error: 'Email already in use.' });
      db.prepare('UPDATE users SET email = ? WHERE id = ?').run(email, user.id);
    }

    if (newPassword) {
      if (!currentPassword) return reply.code(400).send({ error: 'Current password required.' });
      const match = await bcrypt.compare(currentPassword, user.password_hash);
      if (!match) return reply.code(401).send({ error: 'Current password incorrect.' });
      if (!isValidPassword(newPassword)) {
        return reply.code(400).send({ error: 'New password must be at least 8 characters.' });
      }
      const hash = await bcrypt.hash(newPassword, config.bcryptRounds);
      db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, user.id);
      deleteAllSessionsForUser(user.id);
      audit(user.id, 'password_change', {}, request.ip);
    }

    return { message: 'Profile updated.' };
  });

  fastify.get('/api/v1/user/notifications', async (request) => {
    return db
      .prepare(
        'SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 50'
      )
      .all(request.user.id);
  });

  fastify.post('/api/v1/user/notifications/read', async (request) => {
    const { ids } = request.body || {};
    if (Array.isArray(ids) && ids.length > 0) {
      const placeholders = ids.map(() => '?').join(',');
      db.prepare(
        `UPDATE notifications SET read = 1 WHERE id IN (${placeholders}) AND user_id = ?`
      ).run(...ids, request.user.id);
    } else {
      db.prepare('UPDATE notifications SET read = 1 WHERE user_id = ?').run(request.user.id);
    }
    return { message: 'Notifications marked as read.' };
  });

  fastify.get('/api/v1/user/sessions', async (request) => {
    return db
      .prepare(
        'SELECT id, user_agent, ip, created_at, expires_at FROM sessions WHERE user_id = ?'
      )
      .all(request.user.id);
  });

  fastify.delete('/api/v1/user/sessions/:id', async (request, reply) => {
    const session = db
      .prepare('SELECT * FROM sessions WHERE id = ? AND user_id = ?')
      .get(request.params.id, request.user.id);
    if (!session) return reply.code(404).send({ error: 'Session not found.' });
    db.prepare('DELETE FROM sessions WHERE id = ?').run(session.id);
    return { message: 'Session revoked.' };
  });

  // API Key self-service
  fastify.get('/api/v1/user/api-keys', async (request) => {
    return db
      .prepare(
        'SELECT id, key_prefix, permissions, created_at, last_used_at FROM api_keys WHERE user_id = ?'
      )
      .all(request.user.id);
  });

  fastify.post('/api/v1/user/api-keys', async (request, reply) => {
    const { permissions } = request.body || {};
    const VALID_PERMS = ['server:read', 'server:write', 'files:read', 'files:write', 'coins:read'];
    const perms = Array.isArray(permissions)
      ? permissions.filter((p) => VALID_PERMS.includes(p))
      : [];

    const rawKey = 'nxp_' + crypto.randomBytes(32).toString('hex');
    const keyHash = crypto.createHash('sha256').update(rawKey).digest('hex');
    const keyPrefix = rawKey.slice(0, 12);

    db.prepare(
      'INSERT INTO api_keys (user_id, key_hash, key_prefix, permissions) VALUES (?, ?, ?, ?)'
    ).run(request.user.id, keyHash, keyPrefix, JSON.stringify(perms));

    return reply.code(201).send({
      key: rawKey,
      prefix: keyPrefix,
      permissions: perms,
      note: 'Store this key securely. It will not be shown again.'
    });
  });

  fastify.delete('/api/v1/user/api-keys/:id', async (request, reply) => {
    const key = db
      .prepare('SELECT * FROM api_keys WHERE id = ? AND user_id = ?')
      .get(request.params.id, request.user.id);
    if (!key) return reply.code(404).send({ error: 'API key not found.' });
    db.prepare('DELETE FROM api_keys WHERE id = ?').run(key.id);
    return { message: 'API key revoked.' };
  });

  fastify.get('/api/v1/user/referral', async (request) => {
    const user = db
      .prepare('SELECT referral_code FROM users WHERE id = ?')
      .get(request.user.id);
    const referrals = db
      .prepare(
        'SELECT username, created_at FROM users WHERE referred_by = ? ORDER BY created_at DESC'
      )
      .all(request.user.id);
    return { code: user.referral_code, referrals };
  });
}

module.exports = userRoutes;
