'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { pipeline } = require('stream/promises');
const db = require('../../database/db');
const tar = require('../../services/tarStream');
const { isSafePathSegment } = require('../../utils/validate');
const { audit } = require('../../utils/audit');

const SERVERS_DIR = path.resolve(__dirname, '..', '..', 'servers');

function resolveServerPath(uuid, relPath) {
  const base = path.join(SERVERS_DIR, uuid);
  const target = path.resolve(base, relPath || '.');
  if (!target.startsWith(base)) {
    throw new Error('Path traversal detected.');
  }
  return target;
}

function getOwnedServer(serverId, userId) {
  return db
    .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
    .get(serverId, userId);
}

async function fileRoutes(fastify) {
  fastify.addHook('preHandler', fastify.authenticate);

  fastify.get('/api/v1/servers/:id/files', async (request, reply) => {
    const server = getOwnedServer(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const relPath = request.query.path || '.';
    let target;
    try {
      target = resolveServerPath(server.uuid, relPath);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }

    if (!fs.existsSync(target)) {
      fs.mkdirSync(target, { recursive: true });
    }

    const entries = fs.readdirSync(target, { withFileTypes: true });
    return entries.map((e) => {
      const stat = fs.statSync(path.join(target, e.name));
      return {
        name: e.name,
        isDirectory: e.isDirectory(),
        size: stat.size,
        modified: stat.mtimeMs
      };
    });
  });

  fastify.get('/api/v1/servers/:id/files/download', async (request, reply) => {
    const server = getOwnedServer(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    let target;
    try {
      target = resolveServerPath(server.uuid, request.query.path);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
    if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
      return reply.code(404).send({ error: 'File not found.' });
    }

    const basename = path.basename(target);
    return reply
      .header('Content-Disposition', `attachment; filename="${basename}"`)
      .send(fs.createReadStream(target));
  });

  fastify.post('/api/v1/servers/:id/files/upload', async (request, reply) => {
    const server = getOwnedServer(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const data = await request.file();
    if (!data) return reply.code(400).send({ error: 'No file uploaded.' });
    if (!isSafePathSegment(data.filename)) {
      return reply.code(400).send({ error: 'Invalid filename.' });
    }

    const relPath = request.query.path || '.';
    let dirTarget;
    try {
      dirTarget = resolveServerPath(server.uuid, relPath);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
    fs.mkdirSync(dirTarget, { recursive: true });

    const destPath = path.join(dirTarget, data.filename);
    await pipeline(data.file, fs.createWriteStream(destPath));

    audit(request.user.id, 'file_upload', { server: server.name, file: data.filename }, request.ip);
    return reply.code(201).send({ message: 'File uploaded.' });
  });

  fastify.post('/api/v1/servers/:id/files/rename', async (request, reply) => {
    const server = getOwnedServer(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const { from, to } = request.body || {};
    let fromPath, toPath;
    try {
      fromPath = resolveServerPath(server.uuid, from);
      toPath = resolveServerPath(server.uuid, to);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
    if (!fs.existsSync(fromPath)) return reply.code(404).send({ error: 'Source not found.' });

    fs.renameSync(fromPath, toPath);
    return { message: 'Renamed successfully.' };
  });

  fastify.delete('/api/v1/servers/:id/files', async (request, reply) => {
    const server = getOwnedServer(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const body = request.body || {};
    let target;
    try {
      target = resolveServerPath(server.uuid, body.path);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
    if (target === path.join(SERVERS_DIR, server.uuid)) {
      return reply.code(400).send({ error: 'Cannot delete the server root directory.' });
    }
    if (!fs.existsSync(target)) return reply.code(404).send({ error: 'Path not found.' });

    fs.rmSync(target, { recursive: true, force: true });
    audit(request.user.id, 'file_delete', { server: server.name, path: body.path }, request.ip);
    return { message: 'Deleted successfully.' };
  });

  fastify.post('/api/v1/servers/:id/files/zip', async (request, reply) => {
    const server = getOwnedServer(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const body = request.body || {};
    let target;
    try {
      target = resolveServerPath(server.uuid, body.path);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
    if (!fs.existsSync(target)) return reply.code(404).send({ error: 'Path not found.' });

    const outName = (body.archiveName || `${path.basename(target)}_archive`) + '.tar.gz';
    const outPath = path.join(path.dirname(target), outName);

    const tarStream = tar.createTarStream(target);
    const gzip = zlib.createGzip();
    await pipeline(tarStream, gzip, fs.createWriteStream(outPath));

    return reply.code(201).send({ message: 'Archive created.', filename: outName });
  });

  fastify.post('/api/v1/servers/:id/files/mkdir', async (request, reply) => {
    const server = getOwnedServer(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const body = request.body || {};
    let target;
    try {
      target = resolveServerPath(server.uuid, body.path);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
    fs.mkdirSync(target, { recursive: true });
    return reply.code(201).send({ message: 'Directory created.' });
  });

  fastify.get('/api/v1/servers/:id/files/content', async (request, reply) => {
    const server = getOwnedServer(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    let target;
    try {
      target = resolveServerPath(server.uuid, request.query.path);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
    if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
      return reply.code(404).send({ error: 'File not found.' });
    }
    const stat = fs.statSync(target);
    if (stat.size > 2 * 1024 * 1024) {
      return reply.code(413).send({ error: 'File too large to edit in browser (max 2MB).' });
    }
    return { content: fs.readFileSync(target, 'utf8') };
  });

  fastify.put('/api/v1/servers/:id/files/content', async (request, reply) => {
    const server = getOwnedServer(request.params.id, request.user.id);
    if (!server) return reply.code(404).send({ error: 'Server not found.' });

    const body = request.body || {};
    let target;
    try {
      target = resolveServerPath(server.uuid, body.path);
    } catch (err) {
      return reply.code(400).send({ error: err.message });
    }
    if (typeof body.content !== 'string' || body.content.length > 2 * 1024 * 1024) {
      return reply.code(400).send({ error: 'Invalid or oversized content.' });
    }
    fs.writeFileSync(target, body.content, 'utf8');
    return { message: 'File saved.' };
  });
}

module.exports = fileRoutes;
