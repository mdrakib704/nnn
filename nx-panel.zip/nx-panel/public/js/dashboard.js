/* ════════════════════════════════════════════════════════════════
   NX Panel — Dashboard Page
   ════════════════════════════════════════════════════════════════ */

'use strict';

async function loadDashboard() {
  const page = document.getElementById('page-dashboard');
  if (!page) return;
  page.innerHTML = `
    <div class="section-header">
      <div>
        <div class="section-title">Welcome back, ${escHtml(NX.user.username)} 👋</div>
        <div class="section-sub">Here's what's happening with your servers today.</div>
      </div>
      <div class="coins-display">🪙 <span id="dash-coins">${NX.user.coins}</span> Coins</div>
    </div>

    <div class="stat-grid" id="system-stat-grid">
      <div class="stat-card" style="--card-accent:#63b3ed">
        <div class="stat-card-icon">🔲</div>
        <div class="stat-card-value" id="stat-cpu">—</div>
        <div class="stat-card-label">CPU Usage</div>
        <div class="progress-bar mt-4" style="margin-top:8px">
          <div class="progress-fill" id="stat-cpu-bar" style="--fill-color:#63b3ed;width:0%"></div>
        </div>
      </div>
      <div class="stat-card" style="--card-accent:#b794f4">
        <div class="stat-card-icon">🧠</div>
        <div class="stat-card-value" id="stat-ram">—</div>
        <div class="stat-card-label">RAM Usage</div>
        <div class="progress-bar" style="margin-top:8px">
          <div class="progress-fill" id="stat-ram-bar" style="--fill-color:#b794f4;width:0%"></div>
        </div>
      </div>
      <div class="stat-card" style="--card-accent:#f6e05e">
        <div class="stat-card-icon">💾</div>
        <div class="stat-card-value" id="stat-disk">—</div>
        <div class="stat-card-label">Disk Usage</div>
        <div class="progress-bar" style="margin-top:8px">
          <div class="progress-fill" id="stat-disk-bar" style="--fill-color:#f6e05e;width:0%"></div>
        </div>
      </div>
      <div class="stat-card" style="--card-accent:#68d391">
        <div class="stat-card-icon">🌐</div>
        <div class="stat-card-value" id="stat-uptime">—</div>
        <div class="stat-card-label">System Uptime</div>
        <div class="stat-card-sub" id="stat-load">Load: —</div>
      </div>
    </div>

    <div class="section-header mt-4">
      <div class="section-title">Your Servers</div>
      <button class="btn btn-primary btn-sm" onclick="openCreateServerModal()">+ New Server</button>
    </div>
    <div class="server-grid" id="dash-server-grid">
      <div style="grid-column:1/-1;text-align:center;padding:32px;color:var(--text-muted)">
        <div class="spinner"></div>
      </div>
    </div>

    <div class="grid-2 mt-4" style="margin-top:24px">
      <div class="card">
        <div class="card-header">📊 Recent Activity</div>
        <div id="dash-activity" style="max-height:240px;overflow-y:auto">
          <div style="padding:16px;text-align:center;color:var(--text-muted)" class="text-sm">Loading...</div>
        </div>
      </div>
      <div class="card">
        <div class="card-header">🏆 Coin Leaderboard</div>
        <div id="dash-leaderboard" style="max-height:240px;overflow-y:auto">
          <div style="padding:16px;text-align:center;color:var(--text-muted)" class="text-sm">Loading...</div>
        </div>
      </div>
    </div>
  `;

  // Load servers and stats in parallel
  loadDashboardServers();
  loadDashboardActivity();
  loadDashboardLeaderboard();

  // System stats come via WebSocket; load once via HTTP too for initial render
  try {
    const snap = await get('/api/v1/stats/system');
    if (snap) updateSystemStatDisplay(snap);
  } catch {}
}

async function loadDashboardServers() {
  try {
    const servers = await get('/api/v1/servers');
    const grid = document.getElementById('dash-server-grid');
    if (!grid) return;

    if (!servers || servers.length === 0) {
      grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:40px;color:var(--text-muted)">
        <div style="font-size:40px;margin-bottom:12px">🖥</div>
        <div style="font-size:15px;margin-bottom:8px">No servers yet</div>
        <div class="text-sm" style="margin-bottom:16px">Create your first Minecraft server to get started.</div>
        <button class="btn btn-primary btn-sm" onclick="openCreateServerModal()">Create Server</button>
      </div>`;
      return;
    }

    const swEmoji = { paper: '📄', purpur: '🟣', fabric: '🧵', forge: '🔨', vanilla: '🍦' };

    grid.innerHTML = servers.map((s) => {
      const stats = s.stats || {};
      const status = processManager_status(s.status, stats.status);
      return `
      <div class="server-card" onclick="navigate('console',{currentServerId:s.id})">
        <div class="server-card-header">
          <div class="server-icon ${s.software}">${swEmoji[s.software] || '🖥'}</div>
          <div>
            <div class="server-name">${escHtml(s.name)}</div>
            <div class="server-version">${escHtml(s.software)} ${escHtml(s.version)}</div>
          </div>
          <div class="status-dot ${status}"></div>
        </div>
        <div class="server-stats-row">
          <div class="server-stat">
            <div class="server-stat-val">${stats.playersOnline || 0}/${stats.playersMax || 20}</div>
            <div class="server-stat-label">Players</div>
          </div>
          <div class="server-stat">
            <div class="server-stat-val">${stats.tps || '—'}</div>
            <div class="server-stat-label">TPS</div>
          </div>
          <div class="server-stat">
            <div class="server-stat-val">${Math.round(s.ram_mb / 1024 * 10) / 10}GB</div>
            <div class="server-stat-label">RAM</div>
          </div>
          <div class="server-stat">
            <div class="server-stat-val">:${s.port}</div>
            <div class="server-stat-label">Port</div>
          </div>
        </div>
        <div class="server-actions">
          ${status === 'stopped'
            ? `<button class="btn btn-success btn-sm" onclick="event.stopPropagation();serverAction(${s.id},'start')">▶ Start</button>`
            : `<button class="btn btn-warning btn-sm" onclick="event.stopPropagation();serverAction(${s.id},'stop')">■ Stop</button>
               <button class="btn btn-danger btn-xs" onclick="event.stopPropagation();serverAction(${s.id},'restart')">↺ Restart</button>`
          }
          <button class="btn btn-ghost btn-sm" onclick="event.stopPropagation();openServerConsole(${s.id})">📟 Console</button>
          <button class="btn btn-ghost btn-sm" onclick="event.stopPropagation();openServerFiles(${s.id})">📁 Files</button>
        </div>
      </div>`;
    }).join('');
  } catch (err) {
    const grid = document.getElementById('dash-server-grid');
    if (grid) grid.innerHTML = `<div style="grid-column:1/-1;text-align:center;padding:24px;color:var(--accent-red)">${escHtml(err.message)}</div>`;
  }
}

function processManager_status(dbStatus, liveStatus) {
  if (liveStatus) return liveStatus;
  return dbStatus || 'stopped';
}

async function loadDashboardActivity() {
  try {
    const txns = await get('/api/v1/coins/history');
    const el = document.getElementById('dash-activity');
    if (!el) return;
    if (!txns || txns.length === 0) {
      el.innerHTML = '<div style="padding:16px;text-align:center;color:var(--text-muted)" class="text-sm">No recent activity.</div>';
      return;
    }
    el.innerHTML = txns.slice(0, 8).map((t) => `
      <div class="flex items-center gap-3" style="padding:10px 16px;border-bottom:1px solid rgba(255,255,255,0.04)">
        <span>${t.amount > 0 ? '⬆' : '⬇'}</span>
        <div style="flex:1">
          <div class="text-sm">${escHtml(t.description || t.type)}</div>
          <div class="text-xs text-muted">${fmtDate(t.created_at)}</div>
        </div>
        <span class="${t.amount > 0 ? 'text-green' : 'text-red'} font-bold text-sm">
          ${t.amount > 0 ? '+' : ''}${t.amount} 🪙
        </span>
      </div>`).join('');
  } catch {}
}

async function loadDashboardLeaderboard() {
  try {
    const board = await get('/api/v1/coins/leaderboard');
    const el = document.getElementById('dash-leaderboard');
    if (!el) return;
    if (!board || board.length === 0) {
      el.innerHTML = '<div style="padding:16px;text-align:center;color:var(--text-muted)" class="text-sm">No data yet.</div>';
      return;
    }
    const medals = ['🥇', '🥈', '🥉'];
    el.innerHTML = board.map((u, i) => `
      <div class="flex items-center gap-3" style="padding:10px 16px;border-bottom:1px solid rgba(255,255,255,0.04)">
        <span style="width:22px;text-align:center">${medals[i] || (i + 1) + '.'}</span>
        <div class="user-avatar" style="width:28px;height:28px;font-size:12px;flex-shrink:0">${u.username[0].toUpperCase()}</div>
        <span class="text-sm" style="flex:1">${escHtml(u.username)}</span>
        <span class="text-yellow font-bold text-sm">🪙 ${u.coins}</span>
      </div>`).join('');
  } catch {}
}

function updateSystemStatDisplay(snap) {
  const cpuEl   = document.getElementById('stat-cpu');
  const ramEl   = document.getElementById('stat-ram');
  const diskEl  = document.getElementById('stat-disk');
  const uptEl   = document.getElementById('stat-uptime');
  const loadEl  = document.getElementById('stat-load');
  const cpuBar  = document.getElementById('stat-cpu-bar');
  const ramBar  = document.getElementById('stat-ram-bar');
  const diskBar = document.getElementById('stat-disk-bar');

  if (cpuEl && snap.cpu !== undefined) {
    cpuEl.textContent = snap.cpu + '%';
    if (cpuBar) cpuBar.style.width = snap.cpu + '%';
  }
  if (ramEl && snap.memory) {
    ramEl.textContent = snap.memory.usedMb + ' MB';
    if (ramBar) ramBar.style.width = snap.memory.percent + '%';
  }
  if (diskEl && snap.disk) {
    diskEl.textContent = snap.disk.usedMb > 1024
      ? (snap.disk.usedMb / 1024).toFixed(1) + ' GB'
      : snap.disk.usedMb + ' MB';
    if (diskBar) diskBar.style.width = snap.disk.percent + '%';
  }
  if (uptEl && snap.uptimeSec) {
    const h = Math.floor(snap.uptimeSec / 3600);
    const m = Math.floor((snap.uptimeSec % 3600) / 60);
    uptEl.textContent = `${h}h ${m}m`;
  }
  if (loadEl && snap.loadAvg) {
    loadEl.textContent = 'Load: ' + snap.loadAvg.map((v) => v.toFixed(2)).join(' ');
  }
}

// Server quick-actions from dashboard
async function serverAction(serverId, action) {
  try {
    await post(`/api/v1/servers/${serverId}/${action}`);
    toast(`Server ${action} sent.`, 'success');
    setTimeout(loadDashboardServers, 1500);
  } catch (err) {
    toast(err.message, 'error');
  }
}

function openServerConsole(serverId) {
  navigate('console', { currentServerId: serverId });
}

function openServerFiles(serverId) {
  navigate('files', { currentServerId: serverId });
}

// Create server modal
function openCreateServerModal() {
  document.getElementById('modal-create-server').classList.add('open');
}

async function submitCreateServer() {
  const name     = document.getElementById('cs-name').value.trim();
  const software = document.getElementById('cs-software').value;
  const version  = document.getElementById('cs-version').value.trim();
  const errEl    = document.getElementById('cs-error');
  errEl.textContent = '';

  if (!name) { errEl.textContent = 'Server name is required.'; return; }

  const btn = document.getElementById('cs-submit');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Creating...';

  try {
    const result = await post('/api/v1/servers', { name, software, version: version || 'latest' });
    closeModal('modal-create-server');
    toast(`Server "${name}" created! Port: ${result.port}`, 'success');
    document.getElementById('cs-name').value = '';
    if (NX.currentPage === 'dashboard') loadDashboard();
    else if (NX.currentPage === 'servers') loadServersPage();
  } catch (err) {
    errEl.textContent = err.message;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Create Server';
  }
}

function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
}
