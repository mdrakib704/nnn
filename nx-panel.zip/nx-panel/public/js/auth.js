'use strict';

function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach(function(el) {
    el.classList.toggle('active', el.dataset.tab === tab);
  });
  document.getElementById('auth-form-login').style.display    = tab === 'login'    ? 'block' : 'none';
  document.getElementById('auth-form-register').style.display = tab === 'register' ? 'block' : 'none';
  document.getElementById('auth-form-forgot').style.display   = 'none';
  clearAuthMsg();
}

function showForgotPassword() {
  document.querySelectorAll('.auth-tab').forEach(function(el) { el.classList.remove('active'); });
  document.getElementById('auth-form-login').style.display    = 'none';
  document.getElementById('auth-form-register').style.display = 'none';
  document.getElementById('auth-form-forgot').style.display   = 'block';
  clearAuthMsg();
}

function clearAuthMsg() {
  var el = document.getElementById('auth-msg');
  if (el) { el.style.display = 'none'; el.textContent = ''; }
}

function setAuthMsg(message, type) {
  var el = document.getElementById('auth-msg');
  if (!el) return;
  el.className = 'alert alert-' + type;
  el.textContent = message;
  el.style.display = 'flex';
}

async function doLogin(e) {
  if (e) e.preventDefault();
  clearAuthMsg();

  var username   = document.getElementById('login-username').value.trim();
  var password   = document.getElementById('login-password').value;
  var rememberMe = document.getElementById('login-remember').checked;

  if (!username || !password) {
    setAuthMsg('Username and password are required.', 'danger');
    return;
  }

  var btn = document.getElementById('login-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Signing in...';

  try {
    var data = await post('/api/v1/auth/login', {
      username: username,
      password: password,
      rememberMe: rememberMe
    });

    if (!data || !data.accessToken) {
      setAuthMsg('Login failed: no token received.', 'danger');
      return;
    }

    NX.token = data.accessToken;
    NX.user  = data.user;
    document.getElementById('login-password').value = '';

    showPanel();
  } catch (err) {
    setAuthMsg(err.message || 'Login failed.', 'danger');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Sign In';
  }
}

async function doRegister(e) {
  if (e) e.preventDefault();
  clearAuthMsg();

  var username     = document.getElementById('reg-username').value.trim();
  var email        = document.getElementById('reg-email').value.trim();
  var password     = document.getElementById('reg-password').value;
  var confirmPw    = document.getElementById('reg-confirm').value;
  var referralCode = document.getElementById('reg-referral').value.trim();

  if (!username || !email || !password) {
    setAuthMsg('All fields are required.', 'danger'); return;
  }
  if (password !== confirmPw) {
    setAuthMsg('Passwords do not match.', 'danger'); return;
  }
  if (password.length < 8) {
    setAuthMsg('Password must be at least 8 characters.', 'danger'); return;
  }

  var btn = document.getElementById('register-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Creating account...';

  try {
    await post('/api/v1/auth/register', {
      username: username,
      email: email,
      password: password,
      referralCode: referralCode || undefined
    });
    setAuthMsg('Account created! You can now sign in.', 'success');
    ['reg-username','reg-email','reg-password','reg-confirm','reg-referral'].forEach(function(id) {
      document.getElementById(id).value = '';
    });
    setTimeout(function() { switchAuthTab('login'); }, 2000);
  } catch (err) {
    setAuthMsg(err.message || 'Registration failed.', 'danger');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Create Account';
  }
}

async function doForgotPassword(e) {
  if (e) e.preventDefault();
  clearAuthMsg();

  var email = document.getElementById('forgot-email').value.trim();
  if (!email) { setAuthMsg('Email is required.', 'danger'); return; }

  var btn = document.getElementById('forgot-btn');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Sending...';

  try {
    var result = await post('/api/v1/auth/forgot-password', { email: email });
    setAuthMsg(result.message, 'success');
    document.getElementById('forgot-email').value = '';
  } catch (err) {
    setAuthMsg(err.message || 'Request failed.', 'danger');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Send Reset Link';
  }
}

document.addEventListener('keydown', function(e) {
  if (e.key !== 'Enter') return;
  var auth = document.getElementById('auth-screen');
  if (!auth || auth.style.display === 'none') return;
  var loginV  = document.getElementById('auth-form-login').style.display  !== 'none';
  var regV    = document.getElementById('auth-form-register').style.display !== 'none';
  var forgotV = document.getElementById('auth-form-forgot').style.display  !== 'none';
  if (loginV)  doLogin();
  if (regV)    doRegister();
  if (forgotV) doForgotPassword();
});
