/* ════════════════════════════════════════════════════════════════
   NX Panel — Additional Page Loaders
   ════════════════════════════════════════════════════════════════ */

'use strict';

// ════════════════════ SERVERS PAGE ════════════════════════════════
async function loadServersPage() {
  const page = document.getElementById('page-servers');
  if (!page) return;
  page.innerHTML = `
    <div class="section-header">
      <div>
        <div class="section-title">My Servers</div>
        <div class="section-sub">Manage your Minecraft server instances.</div>
      </div>
      <button class="btn btn-primary" onclick="openCreateServerModal()">+ Create Server</button>
    </div>
    <div id="servers-list"><div style="text-align:center;padding:40px"><div class="spinner"></div></div></div>`;

  try {
    const servers = await get('/api/v1/servers');
    const el = document.getElementById('servers-list');
    if (!servers || servers.length === 0) {
      el.innerHTML = `<div class="card" style="text-align:center;padding:48px">
        <div style="font-size:48px;margin-bottom:16px">🖥</div>
        <div style="font-size:16px;margin-bottom:8px">No servers yet</div>
        <button class="btn btn-primary" style="margin-top:8px" onclick="openCreateServerModal()">Create Your First Server</button>
      </div>`;
      return;
    }

    const swEmoji = { paper: '📄', purpur: '🟣', fabric: '🧵', forge: '🔨', vanilla: '🍦' };
    el.innerHTML = `<div class="card"><table class="nx-table">
      <thead><tr>
        <th>Name</th><th>Software</th><th>Status</th><th>Players</th><th>RAM</th><th>Port</th><th>Actions</th>
      </tr></thead>
      <tbody>${servers.map((s) => {
        const stats = s.stats || {};
        const st = stats.status || s.status || 'stopped';
        return `<tr>
          <td><span class="server-icon ${s.software}" style="display:inline-flex;width:28px;height:28px;border-radius:6px;align-items:center;justify-content:center;font-size:14px;margin-right:8px">${swEmoji[s.software] || '🖥'}</span>${escHtml(s.name)}</td>
          <td>${escHtml(s.software)} <span class="text-muted text-xs">${escHtml(s.version)}</span></td>
          <td><span class="badge badge-${st === 'running' ? 'green' : st === 'stopped' ? 'red' : 'yellow'}">${st}</span></td>
          <td>${stats.playersOnline || 0}/${stats.playersMax || 20}</td>
          <td>${Math.round(s.ram_mb / 1024 * 10) / 10} GB</td>
          <td>:${s.port}</td>
          <td class="flex gap-2">
            ${st === 'stopped'
              ? `<button class="btn btn-success btn-xs" onclick="serverAction(${s.id},'start').then(loadServersPage)">▶</button>`
              : `<button class="btn btn-warning btn-xs" onclick="serverAction(${s.id},'stop').then(loadServersPage)">■</button>
                 <button class="btn btn-danger btn-xs" onclick="serverAction(${s.id},'kill').then(loadServersPage)">✕</button>`
            }
            <button class="btn btn-ghost btn-xs" onclick="navigate('console',{currentServerId:${s.id}})">📟</button>
            <button class="btn btn-ghost btn-xs" onclick="navigate('files',{currentServerId:${s.id},filePath:'.'})">📁</button>
            <button class="btn btn-ghost btn-xs" onclick="navigate('backups',{currentServerId:${s.id}})">💾</button>
            <button class="btn btn-danger btn-xs" onclick="confirmDeleteServer(${s.id},'${escHtml(s.name)}')">🗑</button>
          </td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function confirmDeleteServer(id, name) {
  if (!confirm(`Delete server "${name}"? This cannot be undone.`)) return;
  try {
    await del(`/api/v1/servers/${id}`);
    toast('Server deleted.', 'success');
    loadServersPage();
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ════════════════════ CONSOLE PAGE ════════════════════════════════
async function loadConsolePage() {
  const page = document.getElementById('page-console');
  if (!page) return;

  if (!NX.currentServerId) {
    page.innerHTML = `<div class="card" style="text-align:center;padding:40px;color:var(--text-muted)">
      Select a server from <button class="btn btn-ghost btn-sm" onclick="navigate('servers')">My Servers</button> to open its console.
    </div>`;
    return;
  }

  let server;
  try {
    server = await get(`/api/v1/servers/${NX.currentServerId}`);
    NX.serverData = server;
  } catch (err) {
    page.innerHTML = `<div class="alert alert-danger">${escHtml(err.message)}</div>`;
    return;
  }

  const st = server.stats && server.stats.status ? server.stats.status : server.status;

  page.innerHTML = `
    <div class="section-header">
      <div>
        <div class="section-title">📟 ${escHtml(server.name)}</div>
        <div class="section-sub">
          <span class="status-dot ${st}" style="display:inline-block;vertical-align:middle;margin-right:5px"></span>
          ${st} · ${escHtml(server.software)} ${escHtml(server.version)} · Port :${server.port}
        </div>
      </div>
      <div class="flex gap-2">
        ${st === 'stopped'
          ? `<button class="btn btn-success" onclick="consoleServerAction('start')">▶ Start</button>`
          : `<button class="btn btn-warning" onclick="consoleServerAction('stop')">■ Stop</button>
             <button class="btn btn-danger btn-sm" onclick="consoleServerAction('restart')">↺ Restart</button>
             <button class="btn btn-danger btn-sm" onclick="consoleServerAction('kill')">✕ Kill</button>`
        }
      </div>
    </div>

    <div class="grid-2" style="margin-bottom:20px">
      <div class="card">
        <div class="card-header">📈 Server Stats</div>
        <div class="card-body" id="console-stats">
          <div class="resource-row"><span class="resource-label">TPS</span><span id="cstat-tps" class="text-green font-bold">—</span></div>
          <div class="resource-row"><span class="resource-label">Players</span><span id="cstat-players">—</span></div>
          <div class="resource-row"><span class="resource-label">Uptime</span><span id="cstat-uptime" class="text-muted text-sm">—</span></div>
          <div class="resource-row"><span class="resource-label">MSPT</span><span id="cstat-mspt" class="text-muted text-sm">—</span></div>
        </div>
      </div>
      <div class="card">
        <div class="card-header">⚙️ Resources</div>
        <div class="card-body">
          <div class="resource-row">
            <span class="resource-label">RAM</span>
            <div class="resource-bar"><div class="resource-fill ram" style="width:${(server.ram_mb/3072*100).toFixed(0)}%"></div></div>
            <span class="resource-val">${Math.round(server.ram_mb/1024*10)/10} GB</span>
          </div>
          <div class="resource-row">
            <span class="resource-label">CPU</span>
            <div class="resource-bar"><div class="resource-fill cpu" style="width:${server.cpu_percent}%"></div></div>
            <span class="resource-val">${server.cpu_percent}%</span>
          </div>
          <div class="resource-row">
            <span class="resource-label">Disk</span>
            <div class="resource-bar"><div class="resource-fill disk" style="width:${(server.disk_mb/10240*100).toFixed(0)}%"></div></div>
            <span class="resource-val">${Math.round(server.disk_mb/1024*10)/10} GB</span>
          </div>
        </div>
      </div>
    </div>

    <div class="console-wrapper">
      <div class="card-header" style="padding:10px 16px;font-size:13px;border-bottom:1px solid rgba(99,179,237,0.12)">
        <span>📟 Live Console</span>
        <button class="btn btn-ghost btn-xs" style="margin-left:auto" onclick="clearConsole()">Clear</button>
      </div>
      <div class="console-output" id="console-output">Connecting to console...</div>
      <div class="console-input-row">
        <span class="console-prompt">$</span>
        <input class="console-input" id="console-cmd" placeholder="Type a command and press Enter..."
          onkeydown="handleConsoleKey(event)" ${st !== 'running' ? 'disabled' : ''}>
        <button class="btn btn-primary btn-sm" style="margin:6px" onclick="sendConsoleCmd()" ${st !== 'running' ? 'disabled' : ''}>Send</button>
      </div>
    </div>`;

  // Subscribe to this server's console and stats via WebSocket
  wsSubscribe(`console:${server.uuid}`);
  wsSubscribe(`stats:${server.uuid}`);

  // Also load the static log buffer
  try {
    const logData = await get(`/api/v1/servers/${NX.currentServerId}/console`);
    const out = document.getElementById('console-output');
    if (out && logData && logData.logs) {
      out.textContent = logData.logs || '(No console output yet.)';
      out.scrollTop = out.scrollHeight;
    }
  } catch {}
}

function appendConsoleLine(line) {
  const out = document.getElementById('console-output');
  if (!out) return;
  const atBottom = out.scrollHeight - out.clientHeight - out.scrollTop < 40;
  const span = document.createElement('span');
  if (/error|exception|failed/i.test(line)) span.className = 'log-error';
  else if (/warn/i.test(line)) span.className = 'log-warn';
  else if (/\[Server thread\/INFO\]/.test(line)) span.className = 'log-info';
  span.textContent = line;
  out.appendChild(span);
  // Keep buffer manageable in DOM
  while (out.childNodes.length > 1200) out.removeChild(out.firstChild);
  if (atBottom) out.scrollTop = out.scrollHeight;
}

function updateServerStatDisplay(data) {
  const el = (id) => document.getElementById(id);
  if (data.tps !== undefined && el('cstat-tps')) el('cstat-tps').textContent = data.tps;
  if (data.playersOnline !== undefined && el('cstat-players'))
    el('cstat-players').textContent = `${data.playersOnline}/${data.playersMax || 20}`;
  if (data.uptimeMs !== undefined && el('cstat-uptime')) el('cstat-uptime').textContent = fmtUptime(data.uptimeMs);
  if (data.mspt !== undefined && el('cstat-mspt')) el('cstat-mspt').textContent = data.mspt + 'ms';
}

function clearConsole() {
  const out = document.getElementById('console-output');
  if (out) out.textContent = '';
}

function handleConsoleKey(e) {
  if (e.key === 'Enter') sendConsoleCmd();
}

async function sendConsoleCmd() {
  const input = document.getElementById('console-cmd');
  if (!input || !input.value.trim()) return;
  const cmd = input.value.trim();
  input.value = '';
  if (!NX.serverData) { toast('No server selected.', 'error'); return; }
  sendWsCommand(NX.serverData.uuid, cmd);
}

async function consoleServerAction(action) {
  if (!NX.currentServerId) return;
  try {
    await post(`/api/v1/servers/${NX.currentServerId}/${action}`);
    toast(`Server ${action} sent.`, 'success');
    setTimeout(loadConsolePage, 1500);
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ════════════════════ FILE MANAGER PAGE ═══════════════════════════
async function loadFilesPage() {
  const page = document.getElementById('page-files');
  if (!page) return;

  if (!NX.currentServerId) {
    page.innerHTML = `<div class="card" style="text-align:center;padding:40px;color:var(--text-muted)">
      Select a server first. <button class="btn btn-ghost btn-sm" onclick="navigate('servers')">My Servers</button>
    </div>`;
    return;
  }

  const server = NX.serverData || await get(`/api/v1/servers/${NX.currentServerId}`).catch(() => null);
  if (!server) { page.innerHTML = `<div class="alert alert-danger">Server not found.</div>`; return; }
  NX.serverData = server;
  if (!NX.filePath) NX.filePath = '.';

  page.innerHTML = `
    <div class="section-header">
      <div>
        <div class="section-title">📁 File Manager — ${escHtml(server.name)}</div>
        <div class="section-sub">Browse and manage server files.</div>
      </div>
      <div class="flex gap-2">
        <button class="btn btn-primary btn-sm" onclick="openUploadFileModal()">⬆ Upload</button>
        <button class="btn btn-ghost btn-sm" onclick="openMkdirModal()">📁 New Folder</button>
        <button class="btn btn-ghost btn-sm" onclick="navigate('console',{currentServerId:${server.id}})">📟 Console</button>
      </div>
    </div>
    <div class="card">
      <div class="file-breadcrumb" id="file-breadcrumb"></div>
      <div id="file-table-wrapper">
        <div style="padding:24px;text-align:center"><div class="spinner"></div></div>
      </div>
    </div>`;

  renderFileList(NX.filePath);
}

async function renderFileList(relPath) {
  NX.filePath = relPath;
  renderBreadcrumb(relPath);

  const wrapper = document.getElementById('file-table-wrapper');
  if (!wrapper) return;
  wrapper.innerHTML = '<div style="padding:24px;text-align:center"><div class="spinner"></div></div>';

  try {
    const files = await get(`/api/v1/servers/${NX.currentServerId}/files?path=${encodeURIComponent(relPath)}`);
    const sorted = [...(files || [])].sort((a, b) => {
      if (a.isDirectory !== b.isDirectory) return a.isDirectory ? -1 : 1;
      return a.name.localeCompare(b.name);
    });

    wrapper.innerHTML = `<table class="file-table">
      <thead><tr>
        <th style="width:28px"></th><th>Name</th>
        <th class="file-size">Size</th>
        <th class="file-modified">Modified</th>
        <th class="file-actions">Actions</th>
      </tr></thead>
      <tbody>
        ${relPath !== '.' ? `<tr>
          <td class="file-row-icon">📂</td>
          <td class="file-name is-dir" onclick="renderFileList('${escHtml(parentPath(relPath))}')">..</td>
          <td></td><td></td><td></td>
        </tr>` : ''}
        ${sorted.map((f) => {
          const fullPath = relPath === '.' ? f.name : `${relPath}/${f.name}`;
          const icon = f.isDirectory ? '📁' : fileIcon(f.name);
          return `<tr>
            <td class="file-row-icon">${icon}</td>
            <td class="file-name ${f.isDirectory ? 'is-dir' : ''}"
              onclick="${f.isDirectory ? `renderFileList('${escHtml(fullPath)}')` : `editOrDownloadFile('${escHtml(fullPath)}',${f.isDirectory})`}">
              ${escHtml(f.name)}
            </td>
            <td class="file-size">${f.isDirectory ? '—' : fmtBytes(f.size)}</td>
            <td class="file-modified">${fmtDate(f.modified)}</td>
            <td class="file-actions">
              <div class="flex gap-2">
                ${!f.isDirectory ? `<button class="btn btn-ghost btn-xs" onclick="downloadFile('${escHtml(fullPath)}')">⬇</button>` : ''}
                <button class="btn btn-ghost btn-xs" onclick="renameFile('${escHtml(fullPath)}','${escHtml(f.name)}')">✏</button>
                <button class="btn btn-ghost btn-xs" onclick="zipFile('${escHtml(fullPath)}','${escHtml(f.name)}')">🗜</button>
                <button class="btn btn-danger btn-xs" onclick="deleteFile('${escHtml(fullPath)}','${escHtml(f.name)}')">🗑</button>
              </div>
            </td>
          </tr>`;
        }).join('')}
      </tbody>
    </table>`;
  } catch (err) {
    wrapper.innerHTML = `<div class="alert alert-danger" style="margin:16px">${escHtml(err.message)}</div>`;
  }
}

function parentPath(p) {
  const parts = p.split('/').filter(Boolean);
  return parts.length <= 1 ? '.' : parts.slice(0, -1).join('/');
}

function fileIcon(name) {
  const ext = name.split('.').pop().toLowerCase();
  const map = { jar:'📦', json:'📋', yml:'📋', yaml:'📋', txt:'📄', log:'📄',
    properties:'⚙️', sh:'📜', zip:'🗜', gz:'🗜', png:'🖼', jpg:'🖼', mp4:'🎬' };
  return map[ext] || '📄';
}

function renderBreadcrumb(relPath) {
  const el = document.getElementById('file-breadcrumb');
  if (!el) return;
  const parts = relPath === '.' ? [] : relPath.split('/').filter(Boolean);
  let html = `<span class="file-breadcrumb-item" onclick="renderFileList('.')">🏠 Root</span>`;
  let accumulated = '';
  for (const part of parts) {
    accumulated = accumulated ? `${accumulated}/${part}` : part;
    const cur = accumulated;
    html += `<span class="file-breadcrumb-sep">/</span><span class="file-breadcrumb-item" onclick="renderFileList('${escHtml(cur)}')">${escHtml(part)}</span>`;
  }
  el.innerHTML = html;
}

async function editOrDownloadFile(filePath, isDir) {
  if (isDir) return;
  const editExts = ['txt','log','yml','yaml','json','properties','sh','cfg','toml','md','conf'];
  const ext = filePath.split('.').pop().toLowerCase();
  if (editExts.includes(ext)) {
    await openFileEditor(filePath);
  } else {
    downloadFile(filePath);
  }
}

async function openFileEditor(filePath) {
  try {
    const data = await get(`/api/v1/servers/${NX.currentServerId}/files/content?path=${encodeURIComponent(filePath)}`);
    const overlay = document.getElementById('modal-file-editor');
    document.getElementById('file-editor-title').textContent = filePath.split('/').pop();
    document.getElementById('file-editor-path').value = filePath;
    document.getElementById('file-editor-content').value = data.content || '';
    overlay.classList.add('open');
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function saveFileContent() {
  const filePath = document.getElementById('file-editor-path').value;
  const content  = document.getElementById('file-editor-content').value;
  try {
    await put(`/api/v1/servers/${NX.currentServerId}/files/content`, { path: filePath, content });
    toast('File saved.', 'success');
    closeModal('modal-file-editor');
  } catch (err) {
    toast(err.message, 'error');
  }
}

function downloadFile(filePath) {
  const url = `/api/v1/servers/${NX.currentServerId}/files/download?path=${encodeURIComponent(filePath)}`;
  const a = document.createElement('a');
  a.href = url;
  a.download = filePath.split('/').pop();
  a.click();
}

async function renameFile(oldPath, oldName) {
  const newName = prompt('New name:', oldName);
  if (!newName || newName === oldName) return;
  const dirPart = oldPath.includes('/') ? oldPath.substring(0, oldPath.lastIndexOf('/') + 1) : '';
  const newPath = dirPart + newName;
  try {
    await post(`/api/v1/servers/${NX.currentServerId}/files/rename`, { from: oldPath, to: newPath });
    toast('Renamed.', 'success');
    renderFileList(NX.filePath);
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function deleteFile(filePath, name) {
  if (!confirm(`Delete "${name}"?`)) return;
  try {
    await del(`/api/v1/servers/${NX.currentServerId}/files`, { path: filePath });
    toast('Deleted.', 'success');
    renderFileList(NX.filePath);
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function zipFile(filePath, name) {
  try {
    const result = await post(`/api/v1/servers/${NX.currentServerId}/files/zip`, { path: filePath, archiveName: name });
    toast(result.message + ' → ' + result.filename, 'success');
    renderFileList(NX.filePath);
  } catch (err) {
    toast(err.message, 'error');
  }
}

function openUploadFileModal() {
  document.getElementById('modal-upload-file').classList.add('open');
}

async function submitFileUpload() {
  const fileInput = document.getElementById('upload-file-input');
  if (!fileInput.files.length) { toast('No file selected.', 'error'); return; }
  const formData = new FormData();
  formData.append('file', fileInput.files[0]);
  const btn = document.getElementById('upload-file-btn');
  btn.disabled = true;
  btn.textContent = 'Uploading...';
  try {
    const headers = {};
    if (NX.token) headers['Authorization'] = `Bearer ${NX.token}`;
    const res = await fetch(`/api/v1/servers/${NX.currentServerId}/files/upload?path=${encodeURIComponent(NX.filePath)}`, {
      method: 'POST', headers, body: formData, credentials: 'include'
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Upload failed');
    toast('File uploaded.', 'success');
    closeModal('modal-upload-file');
    fileInput.value = '';
    renderFileList(NX.filePath);
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Upload';
  }
}

async function openMkdirModal() {
  const name = prompt('New folder name:');
  if (!name) return;
  const newPath = NX.filePath === '.' ? name : `${NX.filePath}/${name}`;
  try {
    await post(`/api/v1/servers/${NX.currentServerId}/files/mkdir`, { path: newPath });
    toast('Folder created.', 'success');
    renderFileList(NX.filePath);
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ════════════════════ BACKUPS PAGE ════════════════════════════════
async function loadBackupsPage() {
  const page = document.getElementById('page-backups');
  if (!page) return;

  if (!NX.currentServerId) {
    page.innerHTML = `<div class="card" style="text-align:center;padding:40px;color:var(--text-muted)">Select a server first.</div>`;
    return;
  }

  const server = NX.serverData || await get(`/api/v1/servers/${NX.currentServerId}`).catch(() => null);
  if (!server) { page.innerHTML = `<div class="alert alert-danger">Server not found.</div>`; return; }

  page.innerHTML = `
    <div class="section-header">
      <div>
        <div class="section-title">💾 Backups — ${escHtml(server.name)}</div>
        <div class="section-sub">Create and manage server backups.</div>
      </div>
      <button class="btn btn-primary" id="backup-btn" onclick="createBackup()">+ Create Backup</button>
    </div>
    <div id="backups-list"><div style="text-align:center;padding:32px"><div class="spinner"></div></div></div>`;

  renderBackupList(server);
}

async function renderBackupList(server) {
  try {
    const backups = await get(`/api/v1/servers/${server.id}/backups`);
    const el = document.getElementById('backups-list');
    if (!backups || backups.length === 0) {
      el.innerHTML = `<div class="card" style="text-align:center;padding:40px;color:var(--text-muted)">No backups yet.</div>`;
      return;
    }
    el.innerHTML = `<div class="card"><table class="nx-table">
      <thead><tr><th>Filename</th><th>Size</th><th>Created</th><th>Actions</th></tr></thead>
      <tbody>${backups.map((b) => `<tr>
        <td>📦 ${escHtml(b.filename)}</td>
        <td>${fmtBytes(b.size_bytes)}</td>
        <td>${fmtDate(b.created_at)}</td>
        <td class="flex gap-2">
          <a class="btn btn-ghost btn-xs" href="/api/v1/servers/${server.id}/backups/${b.id}/download" download>⬇ Download</a>
          <button class="btn btn-danger btn-xs" onclick="deleteBackup(${server.id},${b.id})">🗑 Delete</button>
        </td>
      </tr>`).join('')}</tbody>
    </table></div>`;
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function createBackup() {
  const btn = document.getElementById('backup-btn');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Backing up...'; }
  try {
    const result = await post(`/api/v1/servers/${NX.currentServerId}/backups`);
    toast(`Backup created: ${result.filename}`, 'success');
    const server = NX.serverData || await get(`/api/v1/servers/${NX.currentServerId}`);
    renderBackupList(server);
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = '+ Create Backup'; }
  }
}

async function deleteBackup(serverId, backupId) {
  if (!confirm('Delete this backup?')) return;
  try {
    await del(`/api/v1/servers/${serverId}/backups/${backupId}`);
    toast('Backup deleted.', 'success');
    const server = NX.serverData || await get(`/api/v1/servers/${serverId}`);
    renderBackupList(server);
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ════════════════════ COINS PAGE ══════════════════════════════════
async function loadCoinsPage() {
  const page = document.getElementById('page-coins');
  if (!page) return;
  page.innerHTML = `<div style="text-align:center;padding:32px"><div class="spinner"></div></div>`;

  try {
    const [balData, history] = await Promise.all([
      get('/api/v1/coins/balance'),
      get('/api/v1/coins/history')
    ]);

    page.innerHTML = `
      <div class="section-title mb-4" style="margin-bottom:20px">🪙 Coin Wallet</div>
      <div class="stat-grid" style="max-width:600px">
        <div class="stat-card" style="--card-accent:#f6e05e">
          <div class="stat-card-icon">🪙</div>
          <div class="stat-card-value">${balData.coins}</div>
          <div class="stat-card-label">Total Coins</div>
        </div>
        <div class="stat-card" style="--card-accent:#68d391">
          <div class="stat-card-icon">📅</div>
          <div class="stat-card-value" id="daily-val">Claim</div>
          <div class="stat-card-label">Daily Reward</div>
          <button class="btn btn-success btn-sm" style="margin-top:8px" onclick="claimDaily()">Claim Now</button>
        </div>
      </div>

      <div class="card" style="margin-top:20px;max-width:600px">
        <div class="card-header">🎟 Redeem Promo Code</div>
        <div class="card-body">
          <div class="flex gap-2">
            <input class="form-input" id="promo-input" placeholder="Enter promo code..." style="flex:1">
            <button class="btn btn-primary" onclick="redeemPromo()">Redeem</button>
          </div>
          <div id="promo-msg" style="margin-top:8px;font-size:13px"></div>
        </div>
      </div>

      <div class="card" style="margin-top:20px">
        <div class="card-header">📋 Transaction History</div>
        ${history && history.length ? `<table class="nx-table">
          <thead><tr><th>Type</th><th>Description</th><th>Amount</th><th>Date</th></tr></thead>
          <tbody>${history.map((t) => `<tr>
            <td><span class="badge badge-${t.amount > 0 ? 'green' : 'red'}">${t.type}</span></td>
            <td class="text-sm">${escHtml(t.description || '—')}</td>
            <td class="${t.amount > 0 ? 'text-green' : 'text-red'} font-bold">${t.amount > 0 ? '+' : ''}${t.amount} 🪙</td>
            <td class="text-muted text-xs">${fmtDate(t.created_at)}</td>
          </tr>`).join('')}</tbody>
        </table>` : `<div style="padding:24px;text-align:center;color:var(--text-muted)">No transactions yet.</div>`}
      </div>`;
  } catch (err) {
    page.innerHTML = `<div class="alert alert-danger">${escHtml(err.message)}</div>`;
  }
}

async function claimDaily() {
  try {
    const result = await post('/api/v1/coins/daily');
    toast(result.message, 'success');
    refreshUserCoins();
    loadCoinsPage();
  } catch (err) {
    const secs = err.data && err.data.remainingSeconds;
    if (secs) {
      const h = Math.floor(secs / 3600);
      const m = Math.floor((secs % 3600) / 60);
      toast(`Already claimed. Next reward in ${h}h ${m}m.`, 'warning');
    } else {
      toast(err.message, 'error');
    }
  }
}

async function redeemPromo() {
  const code = document.getElementById('promo-input').value.trim();
  const msgEl = document.getElementById('promo-msg');
  if (!code) { if (msgEl) msgEl.innerHTML = `<span class="text-red">Enter a promo code.</span>`; return; }
  try {
    const result = await post('/api/v1/coins/promo', { code });
    if (msgEl) msgEl.innerHTML = `<span class="text-green">${escHtml(result.message)}</span>`;
    refreshUserCoins();
    loadCoinsPage();
  } catch (err) {
    if (msgEl) msgEl.innerHTML = `<span class="text-red">${escHtml(err.message)}</span>`;
  }
}

// ════════════════════ SHOP PAGE ═══════════════════════════════════
async function loadShopPage() {
  const page = document.getElementById('page-shop');
  if (!page) return;
  page.innerHTML = `<div style="text-align:center;padding:32px"><div class="spinner"></div></div>`;

  try {
    const [items, servers, balData] = await Promise.all([
      get('/api/v1/shop'),
      get('/api/v1/servers'),
      get('/api/v1/coins/balance')
    ]);

    const typeIcon = { ram: '🧠', cpu: '🔲', disk: '💾', slot: '🖥' };

    page.innerHTML = `
      <div class="section-header mb-4" style="margin-bottom:20px">
        <div><div class="section-title">🛒 Shop</div><div class="section-sub">Upgrade your servers with coins.</div></div>
        <div class="coins-display">🪙 <span id="shop-bal">${balData.coins}</span></div>
      </div>
      ${servers && servers.length > 0 ? `
      <div class="form-group" style="max-width:300px;margin-bottom:20px">
        <label class="form-label">Apply upgrades to server:</label>
        <select class="form-select" id="shop-server-select">
          ${servers.map((s) => `<option value="${s.id}">${escHtml(s.name)}</option>`).join('')}
        </select>
      </div>` : '<div class="alert alert-info" style="margin-bottom:16px">Create a server first to purchase upgrades for it.</div>'}
      <div class="stat-grid">
        ${(items || []).map((item) => `
        <div class="stat-card" style="--card-accent:#63b3ed">
          <div class="stat-card-icon">${typeIcon[item.type] || '⬆'}</div>
          <div class="stat-card-value" style="font-size:20px">${escHtml(item.label)}</div>
          <div class="stat-card-label" style="margin-top:4px">🪙 ${item.price_coins} coins</div>
          <button class="btn btn-primary btn-sm" style="margin-top:12px"
            onclick="buyShopItem(${item.id},'${escHtml(item.type)}','${escHtml(item.label)}',${item.price_coins})">
            Buy
          </button>
        </div>`).join('')}
      </div>`;
  } catch (err) {
    page.innerHTML = `<div class="alert alert-danger">${escHtml(err.message)}</div>`;
  }
}

async function buyShopItem(itemId, type, label, price) {
  if (!confirm(`Purchase "${label}" for 🪙 ${price} coins?`)) return;
  const serverId = type !== 'slot'
    ? (document.getElementById('shop-server-select') ? +document.getElementById('shop-server-select').value : null)
    : null;
  try {
    const result = await post('/api/v1/shop/buy', { itemId, serverId });
    toast(result.message, 'success');
    refreshUserCoins();
    setTimeout(loadShopPage, 600);
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ════════════════════ PROFILE PAGE ════════════════════════════════
async function loadProfilePage() {
  const page = document.getElementById('page-profile');
  if (!page) return;
  const u = NX.user;
  page.innerHTML = `
    <div class="section-title mb-4" style="margin-bottom:20px">👤 My Profile</div>
    <div class="grid-2">
      <div class="card">
        <div class="card-header">Account Information</div>
        <div class="card-body">
          <div class="form-group">
            <label class="form-label">Username</label>
            <input class="form-input" value="${escHtml(u.username)}" disabled>
          </div>
          <div class="form-group">
            <label class="form-label">Email</label>
            <input class="form-input" id="profile-email" value="${escHtml(u.email)}">
          </div>
          <div class="form-group">
            <label class="form-label">Current Password</label>
            <input class="form-input" id="profile-curpw" type="password" placeholder="Required to change password">
          </div>
          <div class="form-group">
            <label class="form-label">New Password</label>
            <input class="form-input" id="profile-newpw" type="password" placeholder="Leave blank to keep current">
          </div>
          <div id="profile-msg" style="margin-bottom:10px"></div>
          <button class="btn btn-primary" onclick="saveProfile()">Save Changes</button>
        </div>
      </div>
      <div class="card">
        <div class="card-header">Referral Program</div>
        <div class="card-body">
          <div class="text-sm text-muted mb-2" style="margin-bottom:8px">Share your referral code to earn coins when friends register.</div>
          <div class="form-group">
            <label class="form-label">Your Referral Code</label>
            <div class="flex gap-2">
              <input class="form-input" id="referral-code" value="${escHtml(u.referral_code || '')}" readonly style="flex:1">
              <button class="btn btn-ghost btn-sm" onclick="copyReferral()">Copy</button>
            </div>
          </div>
          <div id="referral-list" class="mt-4" style="margin-top:12px">
            <div class="text-sm text-muted">Loading referrals...</div>
          </div>
        </div>
      </div>
    </div>
    <div class="card" style="margin-top:20px">
      <div class="card-header">🔑 API Keys</div>
      <div class="card-body">
        <button class="btn btn-primary btn-sm mb-4" style="margin-bottom:12px" onclick="createApiKey()">+ Create API Key</button>
        <div id="api-keys-list"><div class="spinner"></div></div>
      </div>
    </div>`;

  loadReferrals();
  loadApiKeys();
}

async function saveProfile() {
  const email     = document.getElementById('profile-email').value;
  const curPw     = document.getElementById('profile-curpw').value;
  const newPw     = document.getElementById('profile-newpw').value;
  const msg       = document.getElementById('profile-msg');
  msg.innerHTML   = '';
  try {
    await patch('/api/v1/user/me', { email, currentPassword: curPw || undefined, newPassword: newPw || undefined });
    msg.innerHTML = '<span class="text-green">Profile updated.</span>';
    NX.user.email = email;
  } catch (err) {
    msg.innerHTML = `<span class="text-red">${escHtml(err.message)}</span>`;
  }
}

function copyReferral() {
  const el = document.getElementById('referral-code');
  if (el) { navigator.clipboard.writeText(el.value); toast('Referral code copied!', 'success'); }
}

async function loadReferrals() {
  try {
    const data = await get('/api/v1/user/referral');
    const el = document.getElementById('referral-list');
    if (!el) return;
    if (!data.referrals || data.referrals.length === 0) {
      el.innerHTML = '<div class="text-sm text-muted">No referrals yet.</div>';
      return;
    }
    el.innerHTML = `<div class="text-sm font-bold mb-2" style="margin-bottom:6px">Referred Users (${data.referrals.length})</div>
      ${data.referrals.map((r) => `<div class="text-sm" style="padding:4px 0;border-bottom:1px solid rgba(255,255,255,0.05)">
        ${escHtml(r.username)} <span class="text-muted text-xs">— ${fmtDate(r.created_at)}</span>
      </div>`).join('')}`;
  } catch {}
}

async function loadApiKeys() {
  try {
    const keys = await get('/api/v1/user/api-keys');
    const el = document.getElementById('api-keys-list');
    if (!el) return;
    if (!keys || keys.length === 0) {
      el.innerHTML = '<div class="text-sm text-muted">No API keys.</div>';
      return;
    }
    el.innerHTML = `<table class="nx-table">
      <thead><tr><th>Prefix</th><th>Permissions</th><th>Created</th><th>Last Used</th><th>Actions</th></tr></thead>
      <tbody>${keys.map((k) => `<tr>
        <td><code>${escHtml(k.key_prefix)}...</code></td>
        <td class="text-xs">${JSON.parse(k.permissions || '[]').join(', ') || 'none'}</td>
        <td class="text-xs text-muted">${fmtDate(k.created_at)}</td>
        <td class="text-xs text-muted">${fmtDate(k.last_used_at)}</td>
        <td><button class="btn btn-danger btn-xs" onclick="revokeApiKey(${k.id})">Revoke</button></td>
      </tr>`).join('')}</tbody>
    </table>`;
  } catch {}
}

async function createApiKey() {
  const permsInput = prompt('Enter permissions (comma-separated):\nOptions: server:read, server:write, files:read, files:write, coins:read', 'server:read');
  if (permsInput === null) return;
  const permissions = permsInput.split(',').map((p) => p.trim()).filter(Boolean);
  try {
    const result = await post('/api/v1/user/api-keys', { permissions });
    alert(`API Key Created!\n\nKey: ${result.key}\n\n${result.note}`);
    loadApiKeys();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function revokeApiKey(id) {
  if (!confirm('Revoke this API key?')) return;
  try {
    await del(`/api/v1/user/api-keys/${id}`);
    toast('API key revoked.', 'success');
    loadApiKeys();
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ════════════════════ ADMIN PAGES ════════════════════════════════════

async function loadAdminDashboard() {
  const page = document.getElementById('page-admin');
  if (!page) return;
  page.innerHTML = `<div style="text-align:center;padding:32px"><div class="spinner"></div></div>`;
  try {
    const stats = await get('/api/v1/admin/stats');
    page.innerHTML = `
      <div class="section-title mb-4" style="margin-bottom:20px">⚙️ Admin Overview</div>
      <div class="stat-grid">
        <div class="stat-card" style="--card-accent:#63b3ed">
          <div class="stat-card-icon">👥</div>
          <div class="stat-card-value">${stats.totalUsers}</div>
          <div class="stat-card-label">Total Users</div>
        </div>
        <div class="stat-card" style="--card-accent:#b794f4">
          <div class="stat-card-icon">🖥</div>
          <div class="stat-card-value">${stats.totalServers}</div>
          <div class="stat-card-label">Total Servers</div>
        </div>
        <div class="stat-card" style="--card-accent:#68d391">
          <div class="stat-card-icon">🟢</div>
          <div class="stat-card-value">${stats.runningServers}</div>
          <div class="stat-card-label">Running Servers</div>
        </div>
        <div class="stat-card" style="--card-accent:#f6e05e">
          <div class="stat-card-icon">🪙</div>
          <div class="stat-card-value">${stats.totalCoins}</div>
          <div class="stat-card-label">Total Coins in Circulation</div>
        </div>
      </div>
      <div class="card" style="margin-top:20px">
        <div class="card-header">📈 Recent Registrations</div>
        <table class="nx-table">
          <thead><tr><th>Day</th><th>New Users</th></tr></thead>
          <tbody>${(stats.recentRegistrations || []).map((r) => `<tr>
            <td>${r.day}</td><td>${r.count}</td>
          </tr>`).join('')}</tbody>
        </table>
      </div>`;
  } catch (err) {
    page.innerHTML = `<div class="alert alert-danger">${escHtml(err.message)}</div>`;
  }
}

async function loadAdminUsers() {
  const page = document.getElementById('page-admin-users');
  if (!page) return;
  page.innerHTML = `<div class="section-header mb-4" style="margin-bottom:20px">
    <div class="section-title">👥 User Management</div>
    <div class="flex gap-2">
      <input class="form-input" id="admin-user-search" placeholder="Search users..." style="width:200px" oninput="adminSearchUsers()">
    </div>
  </div>
  <div id="admin-users-table"><div style="text-align:center;padding:32px"><div class="spinner"></div></div></div>`;
  adminLoadUsers();
}

async function adminLoadUsers(search = '') {
  try {
    const data = await get(`/api/v1/admin/users?search=${encodeURIComponent(search)}&limit=50`);
    const el = document.getElementById('admin-users-table');
    if (!el) return;
    el.innerHTML = `<div class="card"><table class="nx-table">
      <thead><tr><th>User</th><th>Role</th><th>Coins</th><th>Servers</th><th>Status</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>${(data.users || []).map((u) => `<tr>
        <td>
          <div class="flex items-center gap-2">
            <div class="user-avatar" style="width:28px;height:28px;font-size:12px;flex-shrink:0">${u.username[0].toUpperCase()}</div>
            <div>
              <div class="text-sm font-bold">${escHtml(u.username)}</div>
              <div class="text-xs text-muted">${escHtml(u.email)}</div>
            </div>
          </div>
        </td>
        <td><span class="badge badge-${u.role === 'admin' ? 'purple' : 'blue'}">${u.role}</span></td>
        <td>🪙 ${u.coins}</td>
        <td>${u.server_slots} slots</td>
        <td><span class="badge badge-${u.suspended ? 'red' : 'green'}">${u.suspended ? 'Suspended' : 'Active'}</span></td>
        <td class="text-xs text-muted">${fmtDate(u.created_at)}</td>
        <td>
          <div class="flex gap-1">
            <button class="btn btn-ghost btn-xs" onclick="adminGrantCoins(${u.id},'${escHtml(u.username)}')">🪙</button>
            <button class="btn btn-${u.suspended ? 'success' : 'warning'} btn-xs" onclick="adminToggleSuspend(${u.id},${u.suspended})">
              ${u.suspended ? 'Unsuspend' : 'Suspend'}
            </button>
            <button class="btn btn-danger btn-xs" onclick="adminDeleteUser(${u.id},'${escHtml(u.username)}')">🗑</button>
          </div>
        </td>
      </tr>`).join('')}</tbody>
    </table></div>`;
  } catch (err) {
    toast(err.message, 'error');
  }
}

let adminSearchTimer;
function adminSearchUsers() {
  clearTimeout(adminSearchTimer);
  adminSearchTimer = setTimeout(() => {
    adminLoadUsers(document.getElementById('admin-user-search').value);
  }, 300);
}

async function adminToggleSuspend(id, suspended) {
  try {
    await patch(`/api/v1/admin/users/${id}`, { suspended: suspended ? 0 : 1 });
    toast(suspended ? 'User unsuspended.' : 'User suspended.', 'success');
    adminLoadUsers();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function adminDeleteUser(id, username) {
  if (!confirm(`Delete user "${username}"? This removes all their servers and data.`)) return;
  try {
    await del(`/api/v1/admin/users/${id}`);
    toast('User deleted.', 'success');
    adminLoadUsers();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function adminGrantCoins(id, username) {
  const amt = parseInt(prompt(`Grant/remove coins for ${username}:\n(use negative to remove)`));
  if (isNaN(amt)) return;
  try {
    const result = await post(`/api/v1/admin/users/${id}/coins`, { amount: amt, description: 'Admin grant' });
    toast(result.message, 'success');
    adminLoadUsers();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadAdminServers() {
  const page = document.getElementById('page-admin-servers');
  if (!page) return;
  page.innerHTML = `<div class="section-title mb-4" style="margin-bottom:20px">🖥 All Servers</div>
  <div id="all-servers-table"><div style="text-align:center;padding:32px"><div class="spinner"></div></div></div>`;
  try {
    const servers = await get('/api/v1/admin/servers');
    const el = document.getElementById('all-servers-table');
    el.innerHTML = `<div class="card"><table class="nx-table">
      <thead><tr><th>Name</th><th>Owner</th><th>Software</th><th>Status</th><th>RAM</th><th>Port</th><th>Actions</th></tr></thead>
      <tbody>${(servers || []).map((s) => `<tr>
        <td>${escHtml(s.name)}</td>
        <td class="text-sm text-muted">${escHtml(s.owner_username)}</td>
        <td>${escHtml(s.software)}</td>
        <td><span class="badge badge-${s.status === 'running' ? 'green' : 'red'}">${s.status}</span></td>
        <td>${Math.round(s.ram_mb/1024*10)/10} GB</td>
        <td>:${s.port}</td>
        <td>
          <div class="flex gap-1">
            <button class="btn btn-${s.suspended ? 'success' : 'warning'} btn-xs" onclick="adminToggleServerSuspend(${s.id},${s.suspended})">
              ${s.suspended ? 'Unsuspend' : 'Suspend'}
            </button>
          </div>
        </td>
      </tr>`).join('')}</tbody>
    </table></div>`;
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function adminToggleServerSuspend(id, suspended) {
  try {
    await patch(`/api/v1/admin/servers/${id}`, { suspended: suspended ? 0 : 1 });
    toast('Server updated.', 'success');
    loadAdminServers();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadAdminAds() {
  const page = document.getElementById('page-admin-ads');
  if (!page) return;
  page.innerHTML = `
    <div class="section-header mb-4" style="margin-bottom:20px">
      <div class="section-title">📢 Ad Manager</div>
      <button class="btn btn-primary btn-sm" onclick="openCreateAdModal()">+ Create Ad</button>
    </div>
    <div id="admin-ads-table"><div style="text-align:center;padding:32px"><div class="spinner"></div></div></div>`;
  adminLoadAds();
}

async function adminLoadAds() {
  try {
    const ads = await get('/api/v1/admin/ads');
    const el = document.getElementById('admin-ads-table');
    if (!el) return;
    el.innerHTML = `<div class="card"><table class="nx-table">
      <thead><tr><th>Type</th><th>Title</th><th>Reward</th><th>Impressions</th><th>Enabled</th><th>Actions</th></tr></thead>
      <tbody>${(ads || []).map((a) => `<tr>
        <td><span class="badge badge-blue">${a.type}</span></td>
        <td>${escHtml(a.title)}</td>
        <td>${a.coin_reward > 0 ? '🪙 ' + a.coin_reward : '—'}</td>
        <td>${a.impressions}</td>
        <td><span class="badge badge-${a.enabled ? 'green' : 'red'}">${a.enabled ? 'Yes' : 'No'}</span></td>
        <td>
          <div class="flex gap-1">
            <button class="btn btn-${a.enabled ? 'warning' : 'success'} btn-xs" onclick="adminToggleAd(${a.id},${a.enabled})">
              ${a.enabled ? 'Disable' : 'Enable'}
            </button>
            <button class="btn btn-danger btn-xs" onclick="adminDeleteAd(${a.id})">🗑</button>
          </div>
        </td>
      </tr>`).join('')}</tbody>
    </table></div>`;
  } catch (err) {
    toast(err.message, 'error');
  }
}

function openCreateAdModal() {
  document.getElementById('modal-create-ad').classList.add('open');
}

async function submitCreateAd() {
  const type    = document.getElementById('ad-type').value;
  const title   = document.getElementById('ad-title').value.trim();
  const content = document.getElementById('ad-content').value.trim();
  const reward  = parseInt(document.getElementById('ad-reward').value) || 0;
  const freq    = parseInt(document.getElementById('ad-freq').value) || 60;

  if (!title || !content) { toast('Title and content are required.', 'error'); return; }

  try {
    await post('/api/v1/admin/ads', { type, title, content, coinReward: reward, frequencyMinutes: freq });
    toast('Ad created.', 'success');
    closeModal('modal-create-ad');
    adminLoadAds();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function adminToggleAd(id, enabled) {
  try {
    await patch(`/api/v1/admin/ads/${id}`, { enabled: enabled ? 0 : 1 });
    adminLoadAds();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function adminDeleteAd(id) {
  if (!confirm('Delete this ad?')) return;
  try {
    await del(`/api/v1/admin/ads/${id}`);
    toast('Ad deleted.', 'success');
    adminLoadAds();
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadAdminSettings() {
  const page = document.getElementById('page-admin-settings');
  if (!page) return;
  page.innerHTML = `<div style="text-align:center;padding:32px"><div class="spinner"></div></div>`;

  try {
    const settings = await get('/api/v1/admin/settings');
    page.innerHTML = `
      <div class="section-title mb-4" style="margin-bottom:20px">⚙️ Panel Settings</div>
      <div class="grid-2">
        <div class="card">
          <div class="card-header">General</div>
          <div class="card-body">
            <div class="form-group">
              <label class="form-label">Site Name</label>
              <input class="form-input" id="set-site-name" value="${escHtml(settings.site_name || 'NX Panel')}">
            </div>
            <div class="form-group">
              <label class="form-label">Daily Reward Coins</label>
              <input class="form-input" id="set-daily" type="number" value="${settings.daily_reward_coins || 50}">
            </div>
            <div class="form-group">
              <label class="form-label">Referral Reward Coins</label>
              <input class="form-input" id="set-referral" type="number" value="${settings.referral_reward_coins || 100}">
            </div>
            <button class="btn btn-primary" onclick="saveAdminSettings()">Save Settings</button>
          </div>
        </div>
        <div class="card">
          <div class="card-header">🎬 Background Video</div>
          <div class="card-body">
            <div class="form-group">
              <label class="form-label">Upload Video (MP4/WebM, max 500MB)</label>
              <input type="file" class="form-input" id="bg-video-upload" accept=".mp4,.webm">
            </div>
            <button class="btn btn-primary" onclick="uploadBackgroundVideo()">Upload & Set</button>
            ${settings.background_video ? `
            <div class="mt-4" style="margin-top:12px">
              <div class="text-sm text-muted mb-2">Current: ${escHtml(settings.background_video)}</div>
              <video src="${escHtml(settings.background_video)}" autoplay muted loop style="width:100%;max-height:140px;border-radius:8px;object-fit:cover"></video>
            </div>` : ''}
            <div class="form-group mt-4" style="margin-top:16px">
              <label class="form-label">Opacity (${settings.background_opacity}%)</label>
              <input type="range" min="0" max="100" value="${settings.background_opacity || 18}"
                oninput="this.previousElementSibling.textContent='Opacity ('+this.value+'%)'"
                id="bg-opacity">
            </div>
            <div class="form-group">
              <label class="form-label">Blur (${settings.background_blur}px)</label>
              <input type="range" min="0" max="20" value="${settings.background_blur || 0}"
                oninput="this.previousElementSibling.textContent='Blur ('+this.value+'px)'"
                id="bg-blur">
            </div>
            <button class="btn btn-ghost btn-sm" onclick="saveBgSettings()">Apply Video Settings</button>
          </div>
        </div>
      </div>
      <div class="card" style="margin-top:20px">
        <div class="card-header">📢 Broadcast Announcement</div>
        <div class="card-body">
          <div class="form-group">
            <label class="form-label">Title</label>
            <input class="form-input" id="ann-title" placeholder="Announcement title">
          </div>
          <div class="form-group">
            <label class="form-label">Message</label>
            <textarea class="form-textarea" id="ann-message" placeholder="Announcement message..." style="min-height:80px"></textarea>
          </div>
          <div class="form-group">
            <label class="form-label">Level</label>
            <select class="form-select" id="ann-level">
              <option value="info">Info</option>
              <option value="warning">Warning</option>
              <option value="danger">Danger</option>
              <option value="success">Success</option>
            </select>
          </div>
          <button class="btn btn-primary" onclick="broadcastAnnouncement()">Send to All Users</button>
        </div>
      </div>`;
  } catch (err) {
    page.innerHTML = `<div class="alert alert-danger">${escHtml(err.message)}</div>`;
  }
}

async function saveAdminSettings() {
  try {
    await patch('/api/v1/admin/settings', {
      site_name: document.getElementById('set-site-name').value,
      daily_reward_coins: document.getElementById('set-daily').value,
      referral_reward_coins: document.getElementById('set-referral').value
    });
    toast('Settings saved.', 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function saveBgSettings() {
  try {
    await patch('/api/v1/admin/settings', {
      background_opacity: document.getElementById('bg-opacity').value,
      background_blur: document.getElementById('bg-blur').value
    });
    toast('Background settings saved.', 'success');
    applyBgSettings({
      background_opacity: document.getElementById('bg-opacity').value,
      background_blur: document.getElementById('bg-blur').value
    });
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function uploadBackgroundVideo() {
  const fileInput = document.getElementById('bg-video-upload');
  if (!fileInput.files.length) { toast('Select a file first.', 'error'); return; }
  const formData = new FormData();
  formData.append('file', fileInput.files[0]);
  const headers = {};
  if (NX.token) headers['Authorization'] = `Bearer ${NX.token}`;
  try {
    const res = await fetch('/api/v1/admin/background', { method: 'POST', headers, body: formData, credentials: 'include' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    toast(`Background uploaded: ${data.url}`, 'success');
    applyBgVideo(data.url);
    loadAdminSettings();
  } catch (err) {
    toast(err.message, 'error');
  }
}

function applyBgVideo(url) {
  const video = document.getElementById('bg-video');
  if (video && url) { video.src = url; video.load(); }
}

function applyBgSettings(s) {
  const root = document.documentElement;
  if (s.background_opacity) root.style.setProperty('--bg-opacity', s.background_opacity / 100);
  if (s.background_blur) root.style.setProperty('--bg-blur', s.background_blur + 'px');
  if (s.background_overlay) root.style.setProperty('--bg-overlay-alpha', s.background_overlay / 100);
}

async function broadcastAnnouncement() {
  const title   = document.getElementById('ann-title').value.trim();
  const message = document.getElementById('ann-message').value.trim();
  const level   = document.getElementById('ann-level').value;
  if (!title || !message) { toast('Title and message required.', 'error'); return; }
  try {
    await post('/api/v1/admin/announcements', { title, message, level });
    toast('Announcement sent to all users!', 'success');
    document.getElementById('ann-title').value = '';
    document.getElementById('ann-message').value = '';
  } catch (err) {
    toast(err.message, 'error');
  }
}

async function loadAdminLogs() {
  const page = document.getElementById('page-admin-logs');
  if (!page) return;
  page.innerHTML = `<div class="section-title mb-4" style="margin-bottom:20px">📋 Audit Logs</div>
  <div id="audit-log-table"><div style="text-align:center;padding:32px"><div class="spinner"></div></div></div>`;

  try {
    const logs = await get('/api/v1/admin/logs?limit=100');
    const el = document.getElementById('audit-log-table');
    el.innerHTML = `<div class="card"><table class="nx-table">
      <thead><tr><th>User</th><th>Action</th><th>IP</th><th>Time</th></tr></thead>
      <tbody>${(logs || []).map((l) => `<tr>
        <td class="text-sm">${escHtml(l.username || 'system')}</td>
        <td><span class="badge badge-blue">${escHtml(l.action)}</span></td>
        <td class="text-xs text-muted">${escHtml(l.ip || '—')}</td>
        <td class="text-xs text-muted">${fmtDate(l.created_at)}</td>
      </tr>`).join('')}</tbody>
    </table></div>`;
  } catch (err) {
    toast(err.message, 'error');
  }
}
