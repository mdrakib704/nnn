'use strict';

const NX = {
  token: null,
  user: null,
  ws: null,
  wsChannels: new Set(),
  wsReconnectTimer: null,
  currentPage: null,
  currentServerId: null,
  serverData: null,
  filePath: '.'
};

// ── API Client ────────────────────────────────────────────────────
async function api(method, path, body, opts = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (NX.token) headers['Authorization'] = 'Bearer ' + NX.token;
  if (opts.formData) delete headers['Content-Type'];

  let res;
  try {
    res = await fetch(path, {
      method,
      headers,
      body: opts.formData ? body : (body ? JSON.stringify(body) : undefined),
      credentials: 'include'
    });
  } catch (e) {
    throw new Error('Network error: ' + e.message);
  }

  if (res.status === 401 && !opts.noRefresh) {
    const refreshed = await tryRefreshToken();
    if (refreshed) return api(method, path, body, Object.assign({}, opts, { noRefresh: true }));
    logoutUI();
    return null;
  }

  let data;
  try { data = await res.json(); } catch { data = {}; }
  if (!res.ok) {
    const err = new Error(data.error || 'Request failed');
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

const get   = (p, o)    => api('GET',    p, null, o);
const post  = (p, b, o) => api('POST',   p, b,    o);
const put   = (p, b, o) => api('PUT',    p, b,    o);
const patch = (p, b, o) => api('PATCH',  p, b,    o);
const del   = (p, b, o) => api('DELETE', p, b,    o);

async function tryRefreshToken() {
  try {
    const data = await api('POST', '/api/v1/auth/refresh', null, { noRefresh: true });
    if (data && data.accessToken) {
      NX.token = data.accessToken;
      return true;
    }
  } catch {}
  return false;
}

// ── Toast ─────────────────────────────────────────────────────────
function toast(message, type, duration) {
  type = type || 'info';
  duration = duration || 3500;
  const container = document.getElementById('toast-container');
  if (!container) return;
  const icons = { success: '✓', error: '✕', info: 'ℹ', warning: '⚠' };
  const el = document.createElement('div');
  el.className = 'toast toast-' + type;
  el.innerHTML = '<span>' + (icons[type] || 'ℹ') + '</span><span>' + escHtml(String(message)) + '</span>';
  el.addEventListener('click', function() { el.remove(); });
  container.appendChild(el);
  setTimeout(function() {
    el.style.opacity = '0';
    el.style.transition = 'opacity 0.3s';
    setTimeout(function() { el.remove(); }, 300);
  }, duration);
}

function escHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function fmtDate(ts) {
  if (!ts) return '—';
  const ms = ts > 1e12 ? ts : ts * 1000;
  return new Date(ms).toLocaleString();
}

function fmtBytes(b) {
  if (b === undefined || b === null) return '—';
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1024 / 1024).toFixed(1) + ' MB';
}

function fmtUptime(ms) {
  if (!ms) return '—';
  const s = Math.floor(ms / 1000);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return h + 'h ' + m + 'm';
  if (m > 0) return m + 'm ' + sec + 's';
  return sec + 's';
}

// ── Auth ──────────────────────────────────────────────────────────
async function initAuth() {
  const refreshed = await tryRefreshToken();
  if (refreshed) {
    try {
      NX.user = await get('/api/v1/user/me');
      if (NX.user) {
        showPanel();
        return;
      }
    } catch {}
  }
  showAuth();
}

function showAuth() {
  document.getElementById('auth-screen').style.display = 'flex';
  document.getElementById('panel-screen').style.display = 'none';
}

function showPanel() {
  document.getElementById('auth-screen').style.display = 'none';
  document.getElementById('panel-screen').style.display = 'flex';
  renderSidebar();
  loadAnnouncements();
  connectWebSocket();
  navigate('dashboard');
  scheduleTokenRefresh();
  updateNotificationBadge();
  // Sync coins in header
  const hc = document.getElementById('header-coins-val');
  if (hc && NX.user) hc.textContent = NX.user.coins || 0;
}

function logoutUI() {
  NX.token = null;
  NX.user = null;
  if (NX.ws) { try { NX.ws.close(); } catch {} NX.ws = null; }
  clearTimeout(NX.wsReconnectTimer);
  showAuth();
}

async function doLogout() {
  try { await post('/api/v1/auth/logout'); } catch {}
  logoutUI();
}

function scheduleTokenRefresh() {
  setInterval(async function() {
    if (NX.user) await tryRefreshToken();
  }, 12 * 60 * 1000);
}

// ── Router ────────────────────────────────────────────────────────
const PAGE_LOADERS = {
  dashboard:        loadDashboard,
  servers:          loadServersPage,
  console:          loadConsolePage,
  files:            loadFilesPage,
  backups:          loadBackupsPage,
  coins:            loadCoinsPage,
  shop:             loadShopPage,
  profile:          loadProfilePage,
  admin:            loadAdminDashboard,
  'admin-users':    loadAdminUsers,
  'admin-servers':  loadAdminServers,
  'admin-ads':      loadAdminAds,
  'admin-settings': loadAdminSettings,
  'admin-logs':     loadAdminLogs
};

function navigate(page, data) {
  if (data) Object.assign(NX, data);
  NX.currentPage = page;

  document.querySelectorAll('.nav-item').forEach(function(el) {
    el.classList.toggle('active', el.dataset.page === page);
  });
  document.querySelectorAll('.page').forEach(function(el) {
    el.classList.remove('active');
  });
  var pageEl = document.getElementById('page-' + page);
  if (pageEl) pageEl.classList.add('active');

  var titles = {
    dashboard: '🏠 Dashboard', servers: '🖥 My Servers', console: '📟 Console',
    files: '📁 File Manager', backups: '💾 Backups', coins: '🪙 Coins',
    shop: '🛒 Shop', profile: '👤 Profile', admin: '⚙️ Admin Dashboard',
    'admin-users': '👥 User Management', 'admin-servers': '🖥 All Servers',
    'admin-ads': '📢 Ad Manager', 'admin-settings': '⚙️ Settings',
    'admin-logs': '📋 Audit Logs'
  };
  var titleEl = document.querySelector('.header-title');
  if (titleEl) titleEl.textContent = titles[page] || 'NX Panel';

  if (PAGE_LOADERS[page]) {
    try { PAGE_LOADERS[page](); } catch(e) { console.error('Page load error:', e); }
  }
}

// ── Sidebar ───────────────────────────────────────────────────────
function renderSidebar() {
  if (!NX.user) return;
  var isAdmin = NX.user.role === 'admin';
  var nav = document.getElementById('sidebar-nav');
  if (!nav) return;

  var userItems = [
    { page: 'dashboard', icon: '⊞', label: 'Dashboard' },
    { page: 'servers',   icon: '🖥', label: 'My Servers' },
    { page: 'coins',     icon: '🪙', label: 'Coins' },
    { page: 'shop',      icon: '🛒', label: 'Shop' },
    { page: 'profile',   icon: '👤', label: 'Profile' }
  ];
  var adminItems = [
    { page: 'admin',          icon: '⚙️', label: 'Overview' },
    { page: 'admin-users',    icon: '👥', label: 'Users' },
    { page: 'admin-servers',  icon: '🖥', label: 'All Servers' },
    { page: 'admin-ads',      icon: '📢', label: 'Ad Manager' },
    { page: 'admin-settings', icon: '🔧', label: 'Settings' },
    { page: 'admin-logs',     icon: '📋', label: 'Audit Logs' }
  ];

  var html = '<div class="nav-section-label">Menu</div>';
  userItems.forEach(function(item) {
    html += '<button class="nav-item" data-page="' + item.page + '" onclick="navigate(\'' + item.page + '\')">'
      + '<span class="nav-icon">' + item.icon + '</span> ' + item.label + '</button>';
  });
  if (isAdmin) {
    html += '<div class="nav-section-label">Admin</div>';
    adminItems.forEach(function(item) {
      html += '<button class="nav-item" data-page="' + item.page + '" onclick="navigate(\'' + item.page + '\')">'
        + '<span class="nav-icon">' + item.icon + '</span> ' + item.label + '</button>';
    });
  }
  nav.innerHTML = html;

  var avatar   = document.getElementById('sidebar-avatar');
  var userName = document.getElementById('sidebar-username');
  var userRole = document.getElementById('sidebar-role');
  var userCoins= document.getElementById('sidebar-coins');
  if (avatar)    avatar.textContent  = NX.user.username[0].toUpperCase();
  if (userName)  userName.textContent = NX.user.username;
  if (userRole)  userRole.textContent = NX.user.role === 'admin' ? '👑 Admin' : '👤 User';
  if (userCoins) userCoins.textContent = '🪙 ' + (NX.user.coins || 0);
}

async function refreshUserCoins() {
  try {
    var data = await get('/api/v1/coins/balance');
    if (data && NX.user) {
      NX.user.coins = data.coins;
      var els = ['sidebar-coins', 'header-coins-val', 'dash-coins', 'shop-bal'];
      els.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) el.textContent = (id === 'sidebar-coins' ? '🪙 ' : '') + data.coins;
      });
    }
  } catch {}
}

// ── WebSocket ─────────────────────────────────────────────────────
function connectWebSocket() {
  if (NX.ws && NX.ws.readyState < 2) return;
  var proto = location.protocol === 'https:' ? 'wss' : 'ws';
  try {
    NX.ws = new WebSocket(proto + '://' + location.host + '/ws');
  } catch(e) {
    console.error('WS connect error:', e);
    NX.wsReconnectTimer = setTimeout(connectWebSocket, 5000);
    return;
  }

  NX.ws.addEventListener('open', function() {
    if (!NX.token) return;
    wsSend({ type: 'auth', token: NX.token });
  });

  NX.ws.addEventListener('message', function(ev) {
    var msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    handleWsMessage(msg);
  });

  NX.ws.addEventListener('close', function() {
    clearTimeout(NX.wsReconnectTimer);
    NX.wsReconnectTimer = setTimeout(connectWebSocket, 5000);
  });

  NX.ws.addEventListener('error', function() {
    try { NX.ws.close(); } catch {}
  });
}

function wsSend(obj) {
  if (!NX.ws || NX.ws.readyState !== 1) return false;
  try { NX.ws.send(JSON.stringify(obj)); return true; } catch { return false; }
}

function wsSubscribe(channel) {
  wsSend({ type: 'subscribe', channel: channel });
  NX.wsChannels.add(channel);
}

function handleWsMessage(msg) {
  if (!msg) return;
  if (msg.type === 'auth_ok') {
    wsSend({ type: 'subscribe', channel: 'system' });
    wsSend({ type: 'subscribe', channel: 'notifications' });
    if (NX.serverData && NX.serverData.uuid) {
      wsSend({ type: 'subscribe', channel: 'console:' + NX.serverData.uuid });
      wsSend({ type: 'subscribe', channel: 'stats:' + NX.serverData.uuid });
    }
    return;
  }
  if (msg.channel === 'system' && msg.type === 'system_stats') {
    updateSystemStatDisplay(msg.data);
    return;
  }
  if (msg.channel && msg.channel.startsWith('console:') && msg.type === 'console') {
    appendConsoleLine(msg.line);
    return;
  }
  if (msg.channel && msg.channel.startsWith('stats:') && msg.type === 'server_stats') {
    updateServerStatDisplay(msg.data);
    return;
  }
  if (msg.channel === 'notifications') {
    updateNotificationBadge();
    return;
  }
}

function sendWsCommand(uuid, command) {
  if (!wsSend({ type: 'command', uuid: uuid, command: command })) {
    toast('WebSocket not connected.', 'error');
  }
}

// ── Announcements ─────────────────────────────────────────────────
async function loadAnnouncements() {
  try {
    var items = await get('/api/v1/announcements');
    if (!items || items.length === 0) return;
    var latest = items[0];
    var bar = document.getElementById('announcement-bar');
    if (bar) {
      var lvl = latest.level === 'danger' ? 'red' : latest.level === 'warning' ? 'yellow' : 'blue';
      bar.innerHTML = '<span class="badge badge-' + lvl + '">' + latest.level.toUpperCase() + '</span>'
        + ' <span>' + escHtml(latest.title) + ': ' + escHtml(latest.message) + '</span>'
        + '<button class="btn-icon" style="margin-left:auto;width:24px;height:24px;font-size:12px" onclick="this.parentElement.remove()">✕</button>';
      bar.style.display = 'flex';
    }
  } catch {}
}

async function updateNotificationBadge() {
  try {
    var notes = await get('/api/v1/user/notifications');
    var unread = notes ? notes.filter(function(n) { return !n.read; }).length : 0;
    var badge = document.getElementById('notif-badge');
    if (badge) {
      badge.textContent = unread;
      badge.style.display = unread > 0 ? 'inline' : 'none';
    }
  } catch {}
}

function applyBgSettings(s) {
  var root = document.documentElement;
  if (s.background_opacity !== undefined)
    root.style.setProperty('--bg-opacity', parseFloat(s.background_opacity) / 100);
  if (s.background_blur !== undefined)
    root.style.setProperty('--bg-blur', s.background_blur + 'px');
  if (s.background_overlay !== undefined)
    root.style.setProperty('--bg-overlay-alpha', parseFloat(s.background_overlay) / 100);
}

function applyBgVideo(url) {
  var video = document.getElementById('bg-video');
  if (video && url) { video.src = url; try { video.load(); } catch {} }
}

// boot handled by window.load

// Override initAuth to handle display properly
window.addEventListener('load', async function() {
  // Show auth by default first
  var authEl = document.getElementById('auth-screen');
  var panelEl = document.getElementById('panel-screen');
  if (authEl) authEl.style.display = 'flex';
  if (panelEl) panelEl.style.display = 'none';

  // Try refresh token
  var refreshed = await tryRefreshToken();
  if (refreshed) {
    try {
      NX.user = await get('/api/v1/user/me');
      if (NX.user) {
        showPanel();
        // Load background settings
        try {
          var res = await fetch('/api/v1/admin/settings', {
            headers: { 'Authorization': 'Bearer ' + NX.token }
          });
          if (res.ok) {
            var s = await res.json();
            if (s.background_video) {
              var vid = document.getElementById('bg-video');
              if (vid) { vid.src = s.background_video; try { vid.load(); } catch {} }
            }
            applyBgSettings(s);
          }
        } catch {}
        var hc = document.getElementById('header-coins-val');
        if (hc && NX.user) hc.textContent = NX.user.coins || 0;
        updateNotificationBadge();
        return;
      }
    } catch {}
  }
  // Stay on auth screen
  if (authEl) authEl.style.display = 'flex';
});
