'use strict';

const db = require('../database/db');

function getSetting(key, fallback) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : fallback;
}

function addCoins(userId, amount, type, description) {
  db.prepare('UPDATE users SET coins = coins + ? WHERE id = ?').run(amount, userId);
  db.prepare(
    'INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)'
  ).run(userId, amount, type, description || null);
}

function claimDailyReward(userId) {
  const lastClaim = db
    .prepare(
      `SELECT created_at FROM transactions WHERE user_id = ? AND type = 'daily'
       ORDER BY created_at DESC LIMIT 1`
    )
    .get(userId);

  const now = Math.floor(Date.now() / 1000);
  if (lastClaim && now - lastClaim.created_at < 86400) {
    const remaining = 86400 - (now - lastClaim.created_at);
    const err = new Error('Daily reward already claimed.');
    err.remainingSeconds = remaining;
    throw err;
  }

  const amount = parseInt(getSetting('daily_reward_coins', '50'), 10);
  addCoins(userId, amount, 'daily', 'Daily login reward');
  return amount;
}

function redeemPromo(userId, code) {
  const promo = db.prepare('SELECT * FROM promo_codes WHERE code = ?').get(code);
  if (!promo) throw new Error('Invalid promo code.');
  if (promo.expires_at && promo.expires_at < Math.floor(Date.now() / 1000)) {
    throw new Error('This promo code has expired.');
  }
  if (promo.uses >= promo.max_uses) {
    throw new Error('This promo code has reached its usage limit.');
  }

  const already = db
    .prepare('SELECT id FROM promo_redemptions WHERE promo_id = ? AND user_id = ?')
    .get(promo.id, userId);
  if (already) throw new Error('You have already redeemed this promo code.');

  db.prepare(
    'INSERT INTO promo_redemptions (promo_id, user_id) VALUES (?, ?)'
  ).run(promo.id, userId);
  db.prepare('UPDATE promo_codes SET uses = uses + 1 WHERE id = ?').run(promo.id);

  addCoins(userId, promo.coin_value, 'promo', `Redeemed code ${code}`);
  return promo.coin_value;
}

function purchaseShopItem(userId, itemId, serverId) {
  const item = db
    .prepare('SELECT * FROM shop_items WHERE id = ? AND enabled = 1')
    .get(itemId);
  if (!item) throw new Error('Shop item not found.');

  const user = db.prepare('SELECT coins FROM users WHERE id = ?').get(userId);
  if (user.coins < item.price_coins) throw new Error('Not enough coins.');

  if (item.type === 'slot') {
    db.prepare('UPDATE users SET coins = coins - ?, server_slots = server_slots + ? WHERE id = ?').run(
      item.price_coins,
      item.amount,
      userId
    );
  } else {
    if (!serverId) throw new Error('A target server must be specified for this upgrade.');
    const server = db
      .prepare('SELECT * FROM servers WHERE id = ? AND owner_id = ?')
      .get(serverId, userId);
    if (!server) throw new Error('Server not found.');

    const columnMap = { ram: 'ram_mb', cpu: 'cpu_percent', disk: 'disk_mb' };
    const column = columnMap[item.type];
    if (!column) throw new Error('Unknown upgrade type.');

    db.prepare(
      `UPDATE servers SET ${column} = ${column} + ? WHERE id = ?`
    ).run(item.amount, serverId);
    db.prepare('UPDATE users SET coins = coins - ? WHERE id = ?').run(
      item.price_coins,
      userId
    );
  }

  db.prepare(
    'INSERT INTO transactions (user_id, amount, type, description) VALUES (?, ?, ?, ?)'
  ).run(userId, -item.price_coins, 'purchase', `Purchased: ${item.label}`);

  return true;
}

function getLeaderboard(limit = 10) {
  return db
    .prepare(
      'SELECT username, coins FROM users ORDER BY coins DESC LIMIT ?'
    )
    .all(limit);
}

function getTransactionHistory(userId, limit = 50) {
  return db
    .prepare(
      'SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?'
    )
    .all(userId, limit);
}

module.exports = {
  addCoins,
  claimDailyReward,
  redeemPromo,
  purchaseShopItem,
  getLeaderboard,
  getTransactionHistory
};
