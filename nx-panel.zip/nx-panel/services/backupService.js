'use strict';

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { pipeline } = require('stream/promises');
const tar = require('./tarStream');
const db = require('../database/db');

const SERVERS_DIR = path.resolve(__dirname, '..', 'servers');
const BACKUPS_DIR = path.resolve(__dirname, '..', 'backups');

fs.mkdirSync(BACKUPS_DIR, { recursive: true });

async function createBackup(serverRow) {
  const { id, uuid, name } = serverRow;
  const serverDir = path.join(SERVERS_DIR, uuid);
  if (!fs.existsSync(serverDir)) {
    throw new Error('Server directory does not exist.');
  }

  const serverBackupDir = path.join(BACKUPS_DIR, uuid);
  fs.mkdirSync(serverBackupDir, { recursive: true });

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `${name.replace(/[^a-zA-Z0-9_-]/g, '_')}_${timestamp}.tar.gz`;
  const destPath = path.join(serverBackupDir, filename);

  const gzip = zlib.createGzip({ level: 6 });
  const output = fs.createWriteStream(destPath);
  const tarStream = tar.createTarStream(serverDir);

  await pipeline(tarStream, gzip, output);

  const stat = fs.statSync(destPath);
  db.prepare(
    'INSERT INTO backups (server_id, filename, size_bytes) VALUES (?, ?, ?)'
  ).run(id, filename, stat.size);

  return { filename, sizeBytes: stat.size };
}

function listBackups(serverId) {
  return db
    .prepare('SELECT * FROM backups WHERE server_id = ? ORDER BY created_at DESC')
    .all(serverId);
}

function deleteBackup(backupId, uuid) {
  const backup = db.prepare('SELECT * FROM backups WHERE id = ?').get(backupId);
  if (!backup) throw new Error('Backup not found.');
  const filePath = path.join(BACKUPS_DIR, uuid, backup.filename);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  db.prepare('DELETE FROM backups WHERE id = ?').run(backupId);
}

function getBackupPath(uuid, filename) {
  return path.join(BACKUPS_DIR, uuid, filename);
}

module.exports = { createBackup, listBackups, deleteBackup, getBackupPath };
