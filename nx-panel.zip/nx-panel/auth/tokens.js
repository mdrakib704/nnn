'use strict';

const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const config = require('../config.json');
const db = require('../database/db');

function signAccessToken(user) {
  return jwt.sign(
    { sub: user.id, username: user.username, role: user.role },
    config.jwtSecret,
    { expiresIn: config.jwtExpiresIn }
  );
}

function signRefreshToken(user, rememberMe) {
  const expiresIn = rememberMe ? config.jwtRefreshExpiresIn : '1d';
  return jwt.sign({ sub: user.id, type: 'refresh' }, config.jwtRefreshSecret, {
    expiresIn
  });
}

function verifyAccessToken(token) {
  return jwt.verify(token, config.jwtSecret);
}

function verifyRefreshToken(token) {
  return jwt.verify(token, config.jwtRefreshSecret);
}

const insertSession = db.prepare(
  `INSERT INTO sessions (user_id, refresh_token, user_agent, ip, expires_at)
   VALUES (?, ?, ?, ?, ?)`
);

function createSession(user, refreshToken, userAgent, ip, rememberMe) {
  const ttlSeconds = rememberMe ? 7 * 24 * 3600 : 24 * 3600;
  const expiresAt = Math.floor(Date.now() / 1000) + ttlSeconds;
  const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
  insertSession.run(user.id, tokenHash, userAgent || '', ip || '', expiresAt);
}

function findSessionByToken(refreshToken) {
  const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
  return db
    .prepare('SELECT * FROM sessions WHERE refresh_token = ?')
    .get(tokenHash);
}

function deleteSessionByToken(refreshToken) {
  const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
  db.prepare('DELETE FROM sessions WHERE refresh_token = ?').run(tokenHash);
}

function deleteAllSessionsForUser(userId) {
  db.prepare('DELETE FROM sessions WHERE user_id = ?').run(userId);
}

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
  createSession,
  findSessionByToken,
  deleteSessionByToken,
  deleteAllSessionsForUser
};
